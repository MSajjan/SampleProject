package com.standardchartered.techm.application.glue;

import org.openqa.selenium.Keys;

import com.standardchartered.techm.application.utils.Wrapper;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;

public class LoanDetailsScreen {

	public Wrapper mywrapper= new Wrapper();
	
	@Then("^Enter details in Loan details page$")
	public void Enter_details_in_Loan_Details_page() throws Exception
	{
	mywrapper.hardWait(4000);
	mywrapper.SwitchToWindowViaWindowTitle(BaseClass.driver, "Loan Details");
	mywrapper.hardWait(9000);
	System.out.println("Enter Address Details");		
	mywrapper.clearAndSendKeys(BaseClass.driver,BaseClass.OBJECT.getProperty("Applied_Tenor_Loan_Details"),BaseClass.datamap.get(BaseClass.tempindex).get("Applied_Tenure"));
	mywrapper.clearAndSendKeys(BaseClass.driver,BaseClass.OBJECT.getProperty("Applied_Interest_Rate_Loan_Details"),BaseClass.datamap.get(BaseClass.tempindex).get("Interest_Rate"));	
	mywrapper.clearAndSendKeys(BaseClass.driver,BaseClass.OBJECT.getProperty("Applied_Loan_Amt_Loan_Details"), BaseClass.datamap.get(BaseClass.tempindex).get("Applied_loan_amount"));
	mywrapper.SelectUsingValue(BaseClass.driver,BaseClass.OBJECT.getProperty("Payment_Type_Loan_Details"), BaseClass.datamap.get(BaseClass.tempindex).get("Payment_Type"));
	mywrapper.Keys_clearAndSendKeys(BaseClass.driver,BaseClass.OBJECT.getProperty("Payment_Type_Loan_Details"),Keys.TAB);
	mywrapper.hardWait(2000);
	mywrapper.click(BaseClass.driver,BaseClass.OBJECT.getProperty("Fetch_Loan_Details"));
	mywrapper.hardWait(5000);
	mywrapper.click(BaseClass.driver,BaseClass.OBJECT.getProperty("Calculate_Loan_Details"));
	mywrapper.hardWait(2000);
	
	mywrapper.hardWait(2000);
	mywrapper.click(BaseClass.driver,BaseClass.OBJECT.getProperty("Save_Loan_Details"));
	mywrapper.hardWait(6000);
	}
	
}
