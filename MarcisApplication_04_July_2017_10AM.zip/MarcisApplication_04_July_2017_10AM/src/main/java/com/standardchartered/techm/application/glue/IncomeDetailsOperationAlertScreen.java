package com.standardchartered.techm.application.glue;

import org.apache.log4j.Logger;

import com.standardchartered.techm.application.utils.Wrapper;

import cucumber.api.java.en.Then;

public class IncomeDetailsOperationAlertScreen {
	public Wrapper mywrapper= new Wrapper();
	private Logger oLog = Logger.getLogger(IncomeDetailsOperationAlertScreen.class);
	@Then("^Click Yes button in window Alert popup in IncomeTax Screen$")
	public void clickYesButtonWindowAlertPopup() throws Exception
	{
		mywrapper.AcceptAlertIfPresent(BaseClass.driver);
		mywrapper.hardWait(5000);
		
		
	}

}
