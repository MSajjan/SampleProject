package com.standardchartered.techm.application.glue;

import com.standardchartered.techm.application.utils.Wrapper;

import cucumber.api.java.en.Then;

public class LoanDetailsAlertScreen {

	public Wrapper mywrapper= new Wrapper();
	@Then("^Click Yes button in window Alert popup in Loan details Screen$")
	public void clickYesButtonWindowAlertPopup() throws Exception
	{
		mywrapper.hardWait(2000);
		mywrapper.AcceptAlertIfPresent(BaseClass.driver);
		mywrapper.hardWait(5000);
		
		
	}
	
}
