package com.standardchartered.techm.application.glue;

import com.itextpdf.text.log.SysoLogger;
import com.standardchartered.techm.application.utils.Wrapper;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;

public class FieldInvestigationDetailsScreen {

	
	public Wrapper mywrapper= new Wrapper();
	
	@Then("^Fetch the Application Number and verify the investigation details$")
	public void Enter_details_in_Address_Details_page() throws Exception
	{
		mywrapper.SwitchToDefaultWindow(BaseClass.driver);
		mywrapper.switchToFrame(BaseClass.driver, "menu");
		//get the Business Date and pass into the verified Date
		String systemDate=mywrapper.getText(BaseClass.driver, "//form[@name='APMenu']//table[1]//td[contains(text(),'Business Date:')]").trim().replaceAll("Business Date:", "").trim();
		System.out.println(systemDate);
		mywrapper.hardWait(2000);
		mywrapper.SwitchToDefaultWindow(BaseClass.driver);
		mywrapper.switchToFrame(BaseClass.driver, "content");
		String myLoan=CommonBusinessLogic.LoanNo;
		//mywrapper.clearAndSendKeys(BaseClass.driver,BaseClass.OBJECT.getProperty("loan_applicationno_fieldinvestigation"),CommonBusinessLogic.LoanNo);
/*		mywrapper.javaScriptExec_clearAndSendKeys(BaseClass.driver,BaseClass.OBJECT.getProperty("loan_applicationno_fieldinvestigation"),"PLNAI271447");
		mywrapper.click(BaseClass.driver,BaseClass.OBJECT.getProperty("fetch_fieldinvestigation"));*/
		mywrapper.hardWait(3000);
		mywrapper.SelectUsingValue(BaseClass.driver,BaseClass.OBJECT.getProperty("verifyed_fieldinvestigation"),"Y");
		mywrapper.javaScriptExec_clearAndSendKeys(BaseClass.driver,BaseClass.OBJECT.getProperty("dateofVerificagtion_fieldinvestigation"),systemDate);
		mywrapper.hardWait(2000);
		mywrapper.click(BaseClass.driver, BaseClass.OBJECT.getProperty("save_fieldinvestigation"));
		mywrapper.hardWait(5000);
	}
}
