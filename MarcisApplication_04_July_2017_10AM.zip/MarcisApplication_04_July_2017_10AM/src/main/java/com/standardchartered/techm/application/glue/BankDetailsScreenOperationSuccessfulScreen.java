package com.standardchartered.techm.application.glue;

public class BankDetailsScreenOperationSuccessfulScreen {

}
