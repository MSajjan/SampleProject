package com.standardchartered.techm.application.glue;

import java.io.IOException;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import mx4j.tools.remote.Connection;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class DBConnection {
	
	public Connection con;
	public Statement stmt;
	public ResultSet rs;

	@When("^Make Connection to '(.+)' DB and Enter '(.+)' username and '(.+)' password$")
	
	public void Make_Connection_To_DB(String Url,String username,String password)
	{
		try {
			con = (Connection) DriverManager.getConnection(Url,username,password);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@And("^Send '(.+)' SQL_Query$")
	
	public void Execute_Queries(String Query)
	{
		try {
			stmt = ((java.sql.Connection) con).createStatement();
			rs=stmt.executeQuery(Query);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
	}
	
	@Then("^Print the result$")
	public void Print_Results()
	{
		try {
			while (rs.next()){
				String Value1 = rs.getString(1);								        
			    String Value2 = rs.getString(2);					                               
			    System. out.println(Value1+"  "+Value2);
}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@And("^Close the connection$")
	
	public void Close_DBConnection()
	{
		try {
			con.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
}
