package com.standardchartered.techm.application.glue;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.List;
import java.util.Set;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.standardchartered.techm.application.utils.Wrapper;

import cucumber.api.java.en.Then;

public class DisbursementScreen {
	
public Wrapper mywrapper= new Wrapper();
	
@Then("^Enter details in Disbursement screen$")
public void Enter_details_in_Disbursement_screen() throws InterruptedException, AWTException
{	
	mywrapper.hardWait(10000);
	if(CommonBusinessLogic.ParentWindow!=null)
	{
		mywrapper.SwitchToWindow(BaseClass.driver, CommonBusinessLogic.ParentWindow);
	}
	else
	{
		mywrapper.SwitchToDefaultWindow(BaseClass.driver);
	}
	
	mywrapper.SwitchToDefaultWindow(BaseClass.driver);
	mywrapper.switchToFrame(BaseClass.driver, "content");
	mywrapper.hardWait(2000);
	String LoanAmount=mywrapper.getTextBoxValue(BaseClass.driver,BaseClass.OBJECT.getProperty("Disbursement_LoanAmountToBeCredited"));
	System.out.println(LoanAmount);
	mywrapper.click(BaseClass.driver, BaseClass.OBJECT.getProperty("Disbursement_Amount"));
	BaseClass.driver.findElement(By.xpath(BaseClass.OBJECT.getProperty("Disbursement_Amount"))).clear();
	enterLoanAmount(BaseClass.driver,LoanAmount);
	
	mywrapper.Sendkeys_Tab(BaseClass.driver, BaseClass.OBJECT.getProperty("Disbursement_Amount"),Keys.TAB);
	Thread.sleep(5000);
	mywrapper.SelectUsingValue(BaseClass.driver,BaseClass.OBJECT.getProperty("Disbusement_Account_Type"), BaseClass.datamap.get(BaseClass.tempindex).get("Disbusement_Account_Type"));
	mywrapper.hardWait(5000);
	mywrapper.Sendkeys_Tab(BaseClass.driver, BaseClass.OBJECT.getProperty("Disbusement_Account_Type"), Keys.TAB);
	mywrapper.hardWait(5000);
	mywrapper.javaScriptExec_clearAndSendKeys(BaseClass.driver,BaseClass.OBJECT.getProperty("Disbusement_GL_Code"),BaseClass.datamap.get(BaseClass.tempindex).get("Disbusement_GL_Code"));
	mywrapper.hardWait(2000);
	mywrapper.javaScriptExec_clearAndSendKeys(BaseClass.driver,BaseClass.OBJECT.getProperty("Disbusement_Repayment_Acc_No"),BaseClass.datamap.get(BaseClass.tempindex).get("Disbusement_Repayment_Acc_No"));
	mywrapper.SelectUsingValue(BaseClass.driver,BaseClass.OBJECT.getProperty("Disbusement_Business_Segment"),BaseClass.datamap.get(BaseClass.tempindex).get("Disbusement_Business_Segment"));
	mywrapper.SelectUsingValue(BaseClass.driver,BaseClass.OBJECT.getProperty("Disbusement_Stmt_Frequency"),BaseClass.datamap.get(BaseClass.tempindex).get("Disbusement_Stmt_Frequency"));
	mywrapper.hardWait(2000);
	mywrapper.javaScriptExec_clearAndSendKeys(BaseClass.driver,BaseClass.OBJECT.getProperty("Disbusement_EBBS_Acc_No"), BaseClass.datamap.get(BaseClass.tempindex).get("Disbusement_EBBS_Acc_No"));
	CommonBusinessLogic.ParentWindow=mywrapper.getWindowHandle(BaseClass.driver);
	mywrapper.hardWait(2000);
	mywrapper.javascriptEx_Click(BaseClass.driver, BaseClass.OBJECT.getProperty("Disbusement_Installment_Start_Date"));
	mywrapper.hardWait(20000);
	mywrapper.SwitchToWindowViaWindowTitle(BaseClass.driver, "Calender");
	mywrapper.hardWait(5000);
	mywrapper.javascriptEx_Click(BaseClass.driver,BaseClass.OBJECT.getProperty("Calender_Months"));
	mywrapper.hardWait(5000);
	mywrapper.SelectUsingValue(BaseClass.driver,BaseClass.OBJECT.getProperty("Calender_Months"), "6");
	mywrapper.hardWait(5000);
	mywrapper.javascriptEx_Click(BaseClass.driver,BaseClass.OBJECT.getProperty("Calender_Years"));
	mywrapper.hardWait(10000);
	mywrapper.SelectUsingValue(BaseClass.driver,BaseClass.OBJECT.getProperty("Calender_Years"), "2017");
	mywrapper.hardWait(10000);
	mywrapper.javascriptEx_Click(BaseClass.driver,BaseClass.OBJECT.getProperty("Calender_Date"));
	mywrapper.hardWait(5000);
	mywrapper.SwitchToWindow(BaseClass.driver, CommonBusinessLogic.ParentWindow);
	mywrapper.SwitchToDefaultWindow(BaseClass.driver);
	mywrapper.switchToFrame(BaseClass.driver, BaseClass.OBJECT.getProperty("Content_Frame"));
	mywrapper.hardWait(3000);
}

public void enterLoanAmount(WebDriver driver, String value) throws AWTException
{
	Robot robot = new Robot();
	if(value.isEmpty())
	{
		BaseClass.driver.findElement(By.xpath( BaseClass.OBJECT.getProperty("Disbursement_Amount"))).sendKeys("0");
	}
	else
	{
		//BaseClass.driver.findElement(By.xpath( BaseClass.OBJECT.getProperty("Disbursement_Amount"))).sendKeys("0");

		for(int i=0;i<value.length();i++)
		{
			switch(value.charAt(i))
			{
				case '0':
					robot.keyPress(KeyEvent.VK_0);	
					robot.keyRelease(KeyEvent.VK_0);
					break;
				case '1':
					robot.keyPress(KeyEvent.VK_1);	
					robot.keyRelease(KeyEvent.VK_1);
					break;
				case '2':
					robot.keyPress(KeyEvent.VK_2);	
					robot.keyRelease(KeyEvent.VK_2);
					break;
				case '3':
					robot.keyPress(KeyEvent.VK_3);	
					robot.keyRelease(KeyEvent.VK_3);
					break;
				case '4':
					robot.keyPress(KeyEvent.VK_4);	
					robot.keyRelease(KeyEvent.VK_4);
					break;
				case '5':
					robot.keyPress(KeyEvent.VK_5);	
					robot.keyRelease(KeyEvent.VK_5);
					break;
				case '6':
					robot.keyPress(KeyEvent.VK_6);	
					robot.keyRelease(KeyEvent.VK_6);
					break;
				case '7':
					robot.keyPress(KeyEvent.VK_7);	
					robot.keyRelease(KeyEvent.VK_7);
					break;
				case '8':
					robot.keyPress(KeyEvent.VK_8);	
					robot.keyRelease(KeyEvent.VK_8);
					break;
				case '9':
					robot.keyPress(KeyEvent.VK_9);	
					robot.keyRelease(KeyEvent.VK_9);
					break;
				case '.':
					robot.keyPress(KeyEvent.VK_PERIOD);	
					robot.keyRelease(KeyEvent.VK_PERIOD);
					break;
			}
			System.out.println("Printed the Letter["+value.charAt(i)+"]");
		}
	}
	robot.keyPress(KeyEvent.VK_TAB);
	robot.keyRelease(KeyEvent.VK_TAB);
}
@Then("^Click on Save Button in Disbusement Screen$")
public void clickSaveButtoninDisbusement() throws InterruptedException
{	
	mywrapper.hardWait(2000);
	if(CommonBusinessLogic.ParentWindow!=null)
	{
		mywrapper.SwitchToWindow(BaseClass.driver, CommonBusinessLogic.ParentWindow);
	}
	else
	{
		mywrapper.SwitchToDefaultWindow(BaseClass.driver);
	}
	
	mywrapper.SwitchToDefaultWindow(BaseClass.driver);
	mywrapper.switchToFrame(BaseClass.driver, "content");
	mywrapper.javascriptEx_Click(BaseClass.driver, BaseClass.OBJECT.getProperty("Disbursement_Save"));
	mywrapper.hardWait(5000);
}


@Then("^Click on Cancel Button in Disbusement Screen$")
public void clickCancelButtoninDisbusement() throws InterruptedException
{	
	mywrapper.hardWait(2000);
	if(CommonBusinessLogic.ParentWindow!=null)
	{
		mywrapper.SwitchToWindow(BaseClass.driver, CommonBusinessLogic.ParentWindow);
	}
	else
	{
		mywrapper.SwitchToDefaultWindow(BaseClass.driver);
	}
	
	mywrapper.SwitchToDefaultWindow(BaseClass.driver);
	mywrapper.switchToFrame(BaseClass.driver, "content");
	mywrapper.javascriptEx_Click(BaseClass.driver, BaseClass.OBJECT.getProperty("Disbursement_Cancel"));
	mywrapper.hardWait(5000);
	
}
@Then("^Click on Fwd button and click on Action$")
public void Click_on_Fwd_button_and_click_on_Action() throws Exception
{	
	mywrapper.hardWait(2000);

	if(CommonBusinessLogic.ParentWindow!=null)
	{
		mywrapper.SwitchToWindow(BaseClass.driver, CommonBusinessLogic.ParentWindow);
	}
	else
	{
		mywrapper.SwitchToDefaultWindow(BaseClass.driver);
	}
	
	mywrapper.SwitchToDefaultWindow(BaseClass.driver);
	mywrapper.switchToFrame(BaseClass.driver, "content");
	mywrapper.hardWait(4000);
	mywrapper.javaScriptExec_SendKeys(BaseClass.driver, "//textarea[@name='mszTxtNotes']", "OK approved by DD-Maker Level 1");
	mywrapper.hardWait(1000);
	/*mywrapper.javascriptEx_Click(BaseClass.driver, BaseClass.OBJECT.getProperty("Disbursement_Save"));
	mywrapper.hardWait(4000);*/
	mywrapper.javascriptEx_Click(BaseClass.driver, BaseClass.OBJECT.getProperty("Disbursement_Forward"));
	mywrapper.hardWait(4000);
	mywrapper.click(BaseClass.driver, BaseClass.OBJECT.getProperty("Disbursement_Action"));
	mywrapper.hardWait(2000);
	mywrapper.AcceptAlertIfPresent(BaseClass.driver);
	List<WebElement> element=BaseClass.driver.findElements(By.xpath(BaseClass.OBJECT.getProperty("OperationSucessful")));
	Assert.assertTrue("Operation Successful Message is Not Displayed",element.size()==1);
}


@Then("^Click on Authorise and Action button$")
public void Click_on_Authorise_and_Action_button() throws Exception
{	
	mywrapper.hardWait(2000);
	mywrapper.SwitchToDefaultWindow(BaseClass.driver);
	mywrapper.switchToFrame(BaseClass.driver, "content");
	mywrapper.hardWait(4000);
	CommonBusinessLogic.ParentWindow =mywrapper.getWindowHandle(BaseClass.driver);
	mywrapper.javascriptEx_Click(BaseClass.driver, BaseClass.OBJECT.getProperty("Disbursement_Authorise"));
	mywrapper.hardWait(4000);
	mywrapper.click(BaseClass.driver, BaseClass.OBJECT.getProperty("Disbursement_Action"));
	mywrapper.hardWait(4000);
	mywrapper.AcceptAlertIfPresent(BaseClass.driver);
	mywrapper.hardWait(4000);
	List<WebElement> element=BaseClass.driver.findElements(By.xpath(BaseClass.OBJECT.getProperty("OperationSucessful")));
	Assert.assertTrue("Operation Successful Message is Not Displayed",element.size()==1);
}


	@Then("^Click on the Doc Entry and Navigate to Document Details ChildWindow$")
	public void clickonDocEntryButtoninDisburement() throws InterruptedException
	{	
		mywrapper.hardWait(3000);
		if(CommonBusinessLogic.ParentWindow!=null)
		{
			mywrapper.SwitchToWindow(BaseClass.driver, CommonBusinessLogic.ParentWindow);
		}
		else
		{
			mywrapper.SwitchToDefaultWindow(BaseClass.driver);
		}
		mywrapper.hardWait(3000);
		mywrapper.SwitchToDefaultWindow(BaseClass.driver);
		mywrapper.switchToFrame(BaseClass.driver, "content");
		mywrapper.hardWait(5000);
		CommonBusinessLogic.ParentWindow=mywrapper.getWindowHandle(BaseClass.driver);
		mywrapper.click(BaseClass.driver,BaseClass.OBJECT.getProperty("Docentry_Disbursement"));
		mywrapper.hardWait(9000);
		/*mywrapper.SwitchToWindowViaWindowTitle(BaseClass.driver, "Document Details");
		mywrapper.hardWait(4000);*/
	}
	
	@Then("^Click on the Insurance Details and Navigate to Insurance Details ChildWindow$")
	public void clickonInsuranceDetailsinDisburmentScreen() throws InterruptedException
	{	

		if(CommonBusinessLogic.ParentWindow!=null)
		{
			mywrapper.SwitchToWindow(BaseClass.driver, CommonBusinessLogic.ParentWindow);
		}
		else
		{
			mywrapper.SwitchToDefaultWindow(BaseClass.driver);
		}
		mywrapper.hardWait(3000);
		mywrapper.SwitchToDefaultWindow(BaseClass.driver);
		mywrapper.switchToFrame(BaseClass.driver, "content");
		mywrapper.hardWait(5000);
		CommonBusinessLogic.ParentWindow=mywrapper.getWindowHandle(BaseClass.driver);
		mywrapper.click(BaseClass.driver,BaseClass.OBJECT.getProperty("Insurancedetails_Disbursement"));
		mywrapper.hardWait(10000);
		/*mywrapper.SwitchToWindow(BaseClass.driver, 2);
		mywrapper.hardWait(4000);*/

		Set<String> handles = BaseClass.driver.getWindowHandles();	
		
		handles = BaseClass.driver.getWindowHandles();
		int sizeb=handles.size();
		boolean flag=false;
		mywrapper.hardWait(4000);
		System.out.println("No Of Windows Present \t:\t["+sizeb+"]");
		for(String handle : handles)
		{
		       
		        WebDriver popup = BaseClass.driver.switchTo().window(handle);
		        System.out.println(popup.getTitle());
		       
		        if(popup.getTitle().equalsIgnoreCase("Insurance Details"))
		        {
		        	mywrapper.click(BaseClass.driver, "//input[@name='cmdSave']");
		    		mywrapper.hardWait(4000);
		        	flag=true;
		        }
		        if(flag)
		        	break;
		}
	
		System.out.println("Clicked Save Button for the Insurance Screen");
	/*	mywrapper.click(BaseClass.driver, "//input[@name='cmdSave']");
		mywrapper.hardWait(4000);*/
		
	}

}
