package com.standardchartered.techm.application.glue;

import com.standardchartered.techm.application.utils.Wrapper;

import cucumber.api.java.en.Then;

public class ReferenceScreen {

	public Wrapper mywrapper= new Wrapper();

	@Then("^Add References$")
	public void add_references() throws Exception
	{

		// To add code for adding References
	mywrapper.hardWait(6000);
	mywrapper.SwitchToWindowViaWindowTitle(BaseClass.driver, "Application Reference");
	mywrapper.click(BaseClass.driver, BaseClass.OBJECT.getProperty("Add_Application_References"));
	mywrapper.hardWait(3000);
	mywrapper.SelectUsingValue(BaseClass.driver, BaseClass.OBJECT.getProperty("Reference_Application_References"), BaseClass.datamap.get(BaseClass.tempindex).get("Reference"));
	if(BaseClass.datamap.get(BaseClass.tempindex).get("Reference").equalsIgnoreCase("REL"))
	{
		mywrapper.SelectUsingValue(BaseClass.driver, BaseClass.OBJECT.getProperty("Relation_Application_References"), BaseClass.datamap.get(BaseClass.tempindex).get("Relation"));
	}
	mywrapper.SelectUsingValue(BaseClass.driver, BaseClass.OBJECT.getProperty("Title_Application_References"), BaseClass.datamap.get(BaseClass.tempindex).get("Title"));
	mywrapper.SelectUsingValue(BaseClass.driver, BaseClass.OBJECT.getProperty("Acquainted_Years_Application_References"), BaseClass.datamap.get(BaseClass.tempindex).get("Acquainted_ Years"));
	mywrapper.SelectUsingValue(BaseClass.driver, BaseClass.OBJECT.getProperty("Address_Type_Application_References"), BaseClass.datamap.get(BaseClass.tempindex).get("Address_Type"));
	mywrapper.clearAndSendKeys(BaseClass.driver, BaseClass.OBJECT.getProperty("Address1_Application_References"), BaseClass.datamap.get(BaseClass.tempindex).get("Address1"));
	mywrapper.clearAndSendKeys(BaseClass.driver, BaseClass.OBJECT.getProperty("City_Application_References"), BaseClass.datamap.get(BaseClass.tempindex).get("City"));
	mywrapper.clearAndSendKeys(BaseClass.driver, BaseClass.OBJECT.getProperty("Phone_Application_References"), BaseClass.datamap.get(BaseClass.tempindex).get("Phone1"));
	mywrapper.clearAndSendKeys(BaseClass.driver, BaseClass.OBJECT.getProperty("First_Name_Application_References"), BaseClass.datamap.get(BaseClass.tempindex).get("First_Name"));
	mywrapper.clearAndSendKeys(BaseClass.driver, BaseClass.OBJECT.getProperty("Last_Name_Application_References"), BaseClass.datamap.get(BaseClass.tempindex).get("Last_Name"));
	mywrapper.click(BaseClass.driver,  BaseClass.OBJECT.getProperty("Save_Application_References"));
	mywrapper.hardWait(5000);
	mywrapper.AcceptAlertIfPresent(BaseClass.driver);
	
	}
	
	
	
	
}
