package com.standardchartered.techm.application.glue;

import java.util.Iterator;
import java.util.Set;

import org.apache.log4j.Logger;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;

import com.standardchartered.techm.application.utils.Wrapper;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class ApplicationDetailsScreen {
	public Wrapper mywrapper= new Wrapper();
	private Logger oLog = Logger.getLogger(ApplicationDetailsScreen.class);
	@Then("^Enter details in Application Details page$")
	public void Enter_details_in_Application_Details_page() throws InterruptedException
	{
		mywrapper.hardWait(5000);
		mywrapper.SwitchToDefaultWindow(BaseClass.driver);
		mywrapper.switchToFrame(BaseClass.driver, "content");
		mywrapper.hardWait(9000);
		mywrapper.SelectUsingValue(BaseClass.driver, BaseClass.OBJECT.getProperty("Marital_Status_Application_Details"), BaseClass.datamap.get(BaseClass.tempindex).get("Marital_Status"));
		mywrapper.SelectUsingValue(BaseClass.driver, BaseClass.OBJECT.getProperty("Occupation_Application_Details"), BaseClass.datamap.get(BaseClass.tempindex).get("Occupation"));
		mywrapper.SelectUsingValue(BaseClass.driver, BaseClass.OBJECT.getProperty("Employment_Type_Application_Details"), BaseClass.datamap.get(BaseClass.tempindex).get("Employment_Type"));
		mywrapper.SelectUsingValue(BaseClass.driver, BaseClass.OBJECT.getProperty("Nationality_Application_Details"), BaseClass.datamap.get(BaseClass.tempindex).get("Nationality"));
		mywrapper.SelectUsingValue(BaseClass.driver, BaseClass.OBJECT.getProperty("CDD_Risk_Code_Application_Details"), BaseClass.datamap.get(BaseClass.tempindex).get("CDD_Risk_Code"));
		mywrapper.SelectUsingValue(BaseClass.driver, BaseClass.OBJECT.getProperty("ID_Type_Code_Application_Details"), BaseClass.datamap.get(BaseClass.tempindex).get("ID_Type_Code"));
		mywrapper.SelectUsingValue(BaseClass.driver, BaseClass.OBJECT.getProperty("Qualification_Application_Details"), BaseClass.datamap.get(BaseClass.tempindex).get("Qualification"));
		mywrapper.SelectUsingValue(BaseClass.driver, BaseClass.OBJECT.getProperty("Country_of_Birth_Application_Details"), BaseClass.datamap.get(BaseClass.tempindex).get("Country_Of_Birth"));
		mywrapper.SelectUsingValue(BaseClass.driver, BaseClass.OBJECT.getProperty("DSA_PFC_Application_Details"), BaseClass.datamap.get(BaseClass.tempindex).get("DSA/PFC"));
		mywrapper.javaScriptExec_clearAndSendKeys(BaseClass.driver, BaseClass.OBJECT.getProperty("Passport_No_Application_Details"), BaseClass.datamap.get(BaseClass.tempindex).get("Passport_No"));
		mywrapper.javaScriptExec_clearAndSendKeys(BaseClass.driver, BaseClass.OBJECT.getProperty("Email_Contact_Application_Details"), BaseClass.datamap.get(BaseClass.tempindex).get("Email_Contact"));
		mywrapper.javaScriptExec_clearAndSendKeys(BaseClass.driver, BaseClass.OBJECT.getProperty("eBBs_RelationNo_Application_Details"), BaseClass.datamap.get(BaseClass.tempindex).get("eBBs_RelationNo"));
		mywrapper.javaScriptExec_clearAndSendKeys(BaseClass.driver, BaseClass.OBJECT.getProperty("Dependants_Application_Details"), BaseClass.datamap.get(BaseClass.tempindex).get("Dependants"));
		mywrapper.javaScriptExec_clearAndSendKeys(BaseClass.driver, BaseClass.OBJECT.getProperty("Children_Application_Details"), BaseClass.datamap.get(BaseClass.tempindex).get("Children"));
		mywrapper.javaScriptExec_clearAndSendKeys(BaseClass.driver, BaseClass.OBJECT.getProperty("ID_Details_Application_Details"),BaseClass.datamap.get(BaseClass.tempindex).get("ID_Details"));
		//mywrapper.javaScriptExec_clearAndSendKeys(BaseClass.driver, BaseClass.OBJECT.getProperty("Mobile_No_Application_Details"),BaseClass.datamap.get(BaseClass.tempindex).get("mobile_no"));
		mywrapper.javaScriptExec_clearAndSendKeys(BaseClass.driver, "//input[@name='nsztxtMobileNo']", "123456789");
		mywrapper.click(BaseClass.driver, BaseClass.OBJECT.getProperty("US_Resident_Application_Details"));
		mywrapper.click(BaseClass.driver, BaseClass.OBJECT.getProperty("US_Citizen_Application_Details"));
		mywrapper.click(BaseClass.driver, BaseClass.OBJECT.getProperty("Green_card_Application_Details"));
		//Clicking on Product Detail Button
		CommonBusinessLogic.ParentWindow=mywrapper.getWindowHandle(BaseClass.driver);
		mywrapper.click(BaseClass.driver,BaseClass.OBJECT.getProperty("Product_Detail_Button"));	
		mywrapper.hardWait(5000);
	}

	@Then("^Enter product details section in Application Details page$")
	public void Enter_product_details_section_in_Application_Details_page() throws InterruptedException
	{
		oLog.info(CommonBusinessLogic.ParentWindow);
		mywrapper.SwitchToWindow(BaseClass.driver, CommonBusinessLogic.ParentWindow);
		mywrapper.hardWait(5000);
		mywrapper.SwitchToDefaultWindow(BaseClass.driver);
		mywrapper.switchToFrame(BaseClass.driver, "content");
		mywrapper.hardWait(2000);
		mywrapper.javaScriptExec_clearAndSendKeys(BaseClass.driver, BaseClass.OBJECT.getProperty("Dealer_Time_hr_Application_Details"), BaseClass.datamap.get(BaseClass.tempindex).get("Time_Received_at_Dealer_HH"));
		mywrapper.javaScriptExec_clearAndSendKeys(BaseClass.driver, BaseClass.OBJECT.getProperty("Dealer_Time_mm_Application_Details"), BaseClass.datamap.get(BaseClass.tempindex).get("Time_Received_at_Dealer_MM"));
		mywrapper.javaScriptExec_clearAndSendKeys(BaseClass.driver, BaseClass.OBJECT.getProperty("LoanCenter_Time_hr_Application_Details"), BaseClass.datamap.get(BaseClass.tempindex).get("Time_Received_at_loan_Center_HH"));
		mywrapper.javaScriptExec_clearAndSendKeys(BaseClass.driver, BaseClass.OBJECT.getProperty("LoanCenter_Time_mm_Application_Details"), BaseClass.datamap.get(BaseClass.tempindex).get("Time_Received_at_loan_Center_MM"));
		mywrapper.SelectUsingValue(BaseClass.driver, BaseClass.OBJECT.getProperty("Purpose_dw_Application_Details"), BaseClass.datamap.get(BaseClass.tempindex).get("Purpose"));
		mywrapper.SelectUsingValue(BaseClass.driver, BaseClass.OBJECT.getProperty("Origination_branch_dw_Application_Details"), BaseClass.datamap.get(BaseClass.tempindex).get("Origination_Branch"));

		mywrapper.SelectUsingValue(BaseClass.driver, BaseClass.OBJECT.getProperty("Closing_ID_Application_Details"), BaseClass.datamap.get(BaseClass.tempindex).get("Closing_ID"));

		//Enter Customer Received Date and Date Signed


		CommonBusinessLogic.mainwindow=BaseClass.driver.getWindowHandle();
		CommonBusinessLogic.ParentWindow=mywrapper.getWindowHandle(BaseClass.driver);
		
	
		
		mywrapper.hardWait(2000);
		//mywrapper.click(BaseClass.driver, "//input[@name='sztxtDateRec']//following-sibling::a/img");
		mywrapper.click(BaseClass.driver, BaseClass.OBJECT.getProperty("Customer_Date_Application_Details"));
		mywrapper.hardWait(20000);
		mywrapper.SwitchToWindowViaWindowTitle(BaseClass.driver, "Calender");
		mywrapper.hardWait(5000);
		mywrapper.javascriptEx_Click(BaseClass.driver,BaseClass.OBJECT.getProperty("Calender_Months"));
		mywrapper.hardWait(5000);
		mywrapper.SelectUsingValue(BaseClass.driver,BaseClass.OBJECT.getProperty("Calender_Months"), "5");
		mywrapper.hardWait(5000);
		mywrapper.javascriptEx_Click(BaseClass.driver,BaseClass.OBJECT.getProperty("Calender_Years"));
		mywrapper.hardWait(10000);
		mywrapper.SelectUsingValue(BaseClass.driver,BaseClass.OBJECT.getProperty("Calender_Years"), "2017");
		mywrapper.hardWait(10000);
		String actualDate=BaseClass.OBJECT.getProperty("Calender_Date").replace("", "");
		mywrapper.javascriptEx_Click(BaseClass.driver,"//a/font[text()='2']");
		mywrapper.hardWait(10000);


		mywrapper.SwitchToWindow(BaseClass.driver, CommonBusinessLogic.mainwindow);
		mywrapper.SwitchToDefaultWindow(BaseClass.driver);
		mywrapper.switchToFrame(BaseClass.driver, BaseClass.OBJECT.getProperty("Content_Frame"));
		mywrapper.hardWait(5000);

		
		
		

		CommonBusinessLogic.ParentWindow=mywrapper.getWindowHandle(BaseClass.driver);
		mywrapper.hardWait(2000);
		//	mywrapper.click(BaseClass.driver, "//input[@name='sztxtDateRecAtLC']//following-sibling::a/img");
		mywrapper.click(BaseClass.driver, BaseClass.OBJECT.getProperty("Date_Loan_Application_Details"));
		mywrapper.hardWait(20000);
		mywrapper.SwitchToWindowViaWindowTitle(BaseClass.driver, "Calender");
		mywrapper.hardWait(5000);
		mywrapper.javascriptEx_Click(BaseClass.driver,BaseClass.OBJECT.getProperty("Calender_Months"));
		mywrapper.hardWait(5000);
		mywrapper.SelectUsingValue(BaseClass.driver,BaseClass.OBJECT.getProperty("Calender_Months"), "5");
		mywrapper.hardWait(5000);
		mywrapper.javascriptEx_Click(BaseClass.driver,BaseClass.OBJECT.getProperty("Calender_Years"));
		mywrapper.hardWait(10000);
		mywrapper.SelectUsingValue(BaseClass.driver,BaseClass.OBJECT.getProperty("Calender_Years"), "2017");
		mywrapper.hardWait(10000);
		mywrapper.javascriptEx_Click(BaseClass.driver,"//a/font[text()='3']");
		mywrapper.hardWait(10000);
		//mywrapper.SwitchToDefaultWindow(BaseClass.driver);

		mywrapper.SwitchToWindow(BaseClass.driver, CommonBusinessLogic.mainwindow);
		mywrapper.SwitchToDefaultWindow(BaseClass.driver);
		mywrapper.switchToFrame(BaseClass.driver, BaseClass.OBJECT.getProperty("Content_Frame"));
		mywrapper.hardWait(3000);

		System.out.println("Delivered Date\t:\t["+CommonBusinessLogic.businessDate+"]");
		System.out.println("Customer Signed Date\t:\t"+CommonBusinessLogic.customersignedDate+"]");
		mywrapper.click(BaseClass.driver, BaseClass.OBJECT.getProperty("Save_Button_Application_Details"));

	}

	@Then("^Store Loan Details$")
	public void store_Loan_Details() throws InterruptedException
	{
		mywrapper.hardWait(10000);
		mywrapper.SwitchToWindow(BaseClass.driver, CommonBusinessLogic.ParentWindow);
		mywrapper.hardWait(5000);
		mywrapper.SwitchToDefaultWindow(BaseClass.driver);
		mywrapper.switchToFrame(BaseClass.driver, "content");
		mywrapper.hardWait(2000);
		CommonBusinessLogic.LoanNo=mywrapper.getTextBoxValue(BaseClass.driver,BaseClass.OBJECT.getProperty("Loan_No_Application_Details"));
		CommonBusinessLogic.CusNo=mywrapper.getTextBoxValue(BaseClass.driver,BaseClass.OBJECT.getProperty("Cus_No_Application_Details"));
		oLog.info("Loan Appln. No.\t:\t["+CommonBusinessLogic.LoanNo+"]");
		oLog.info("Customer No.\t:\t["+CommonBusinessLogic.CusNo+"]");
		System.out.println("Loan Appln. No.\t:\t["+CommonBusinessLogic.LoanNo+"]");
		System.out.println("Customer No.\t:\t["+CommonBusinessLogic.CusNo+"]");
	}
	@Then("^Get CurrentWindow$")
	public void getCurrentWindow()
	{
		CommonBusinessLogic.mainwindow=mywrapper.getWindowHandle(BaseClass.driver);
	}

	@Then("^Click on Bank Details Button$")
	public void Click_on_Bank_Details_Button() throws InterruptedException
	{
		mywrapper.hardWait(3000);
		if(CommonBusinessLogic.ParentWindow!=null)
		{
			mywrapper.SwitchToWindow(BaseClass.driver, CommonBusinessLogic.ParentWindow);
		}
		else
		{
			mywrapper.SwitchToDefaultWindow(BaseClass.driver);
		}
		mywrapper.SwitchToDefaultWindow(BaseClass.driver);
		mywrapper.switchToFrame(BaseClass.driver, "content");
		mywrapper.hardWait(2000);
		CommonBusinessLogic.ParentWindow=mywrapper.getWindowHandle(BaseClass.driver);
		CommonBusinessLogic.mainwindow=BaseClass.driver.getWindowHandle();
		mywrapper.hardWait(1000);
		mywrapper.javascriptEx_Click(BaseClass.driver,BaseClass.OBJECT.getProperty("Bank_Details_Application_Details"));
	}

	@Then("^Click on Address Details Button$")
	public void Click_on_Address_Details_Button() throws InterruptedException
	{
		if(CommonBusinessLogic.mainwindow!=null)
		{
			mywrapper.SwitchToWindow(BaseClass.driver, CommonBusinessLogic.mainwindow);
		}
		else
		{
			mywrapper.SwitchToDefaultWindow(BaseClass.driver);
		}
		mywrapper.hardWait(5000);
		mywrapper.SwitchToDefaultWindow(BaseClass.driver);
		mywrapper.switchToFrame(BaseClass.driver, "content");
		mywrapper.hardWait(2000);
		CommonBusinessLogic.ParentWindow=mywrapper.getWindowHandle(BaseClass.driver);
		mywrapper.click(BaseClass.driver, BaseClass.OBJECT.getProperty("Address_Details_Application_Details"));
	}

	@Then("^Click on IncomeTax Details Button in the Applicant Details Screen$")
	public void Click_on_IncomeTax_Details_Button() throws InterruptedException
	{
		//mywrapper.SwitchToDefaultWindow(BaseClass.driver);
		if(CommonBusinessLogic.mainwindow!=null)
		{
			mywrapper.SwitchToWindow(BaseClass.driver, CommonBusinessLogic.mainwindow);
		}
		else
		{
			mywrapper.SwitchToDefaultWindow(BaseClass.driver);
		}
		mywrapper.hardWait(9000);
		mywrapper.SwitchToDefaultWindow(BaseClass.driver);
		mywrapper.switchToFrame(BaseClass.driver, "content");
		mywrapper.hardWait(5000);
		CommonBusinessLogic.ParentWindow=mywrapper.getWindowHandle(BaseClass.driver);
		mywrapper.click(BaseClass.driver,BaseClass.OBJECT.getProperty("Income_Details_Application_Details"));


	}

	@Then("^Click on Employment Details Button in the Applicant Details Screen$")
	public void Click_on_Employment_Details_Button() throws InterruptedException
	{
		mywrapper.hardWait(2000);
		if(CommonBusinessLogic.mainwindow!=null)
		{
			mywrapper.SwitchToWindow(BaseClass.driver, CommonBusinessLogic.mainwindow);
		}
		else
		{
			mywrapper.SwitchToDefaultWindow(BaseClass.driver);
		}
		mywrapper.hardWait(5000);
		mywrapper.SwitchToDefaultWindow(BaseClass.driver);
		mywrapper.switchToFrame(BaseClass.driver, "content");
		CommonBusinessLogic.ParentWindow=mywrapper.getWindowHandle(BaseClass.driver);
		mywrapper.click(BaseClass.driver,BaseClass.OBJECT.getProperty("Employment_Dets_Application_Details"));
		mywrapper.hardWait(5000);


	}
	@Then("^Click on MainScreen Button in the Applicant Details Screen$")
	public void Click_on_MainScreen_Button() throws InterruptedException
	{
		mywrapper.hardWait(4000);
		if(CommonBusinessLogic.mainwindow!=null)
		{
			mywrapper.SwitchToWindow(BaseClass.driver, CommonBusinessLogic.mainwindow);
		}
		else
		{
			mywrapper.SwitchToWindow(BaseClass.driver, 0);
			
		}
		mywrapper.hardWait(2000);
		mywrapper.SwitchToDefaultWindow(BaseClass.driver);
		mywrapper.switchToFrame(BaseClass.driver, "content");
		mywrapper.hardWait(2000);
		mywrapper.click(BaseClass.driver, BaseClass.OBJECT.getProperty("Main_Screen_Application_Details"));
	}

	@Then("^Click on Save Button in the Applicant Details Screen$")
	public void Click_on_Save_Button() throws InterruptedException
	{
		oLog.info(CommonBusinessLogic.ParentWindow);
		mywrapper.SwitchToWindow(BaseClass.driver, CommonBusinessLogic.ParentWindow);
		mywrapper.hardWait(5000);
		mywrapper.SwitchToWindow(BaseClass.driver, CommonBusinessLogic.ParentWindow);
		mywrapper.hardWait(5000);
		mywrapper.SwitchToDefaultWindow(BaseClass.driver);
		mywrapper.switchToFrame(BaseClass.driver, "content");
		mywrapper.hardWait(2000);
		mywrapper.click(BaseClass.driver, BaseClass.OBJECT.getProperty(""));
	}

	@Then("^Click on Cancel Button in the Applicant Details Screen$")
	public void Click_on_Cancel_Button() throws InterruptedException
	{
		mywrapper.SwitchToWindow(BaseClass.driver, CommonBusinessLogic.ParentWindow);
		mywrapper.hardWait(5000);
		mywrapper.SwitchToDefaultWindow(BaseClass.driver);
		mywrapper.switchToFrame(BaseClass.driver, "content");
		mywrapper.hardWait(2000);
		mywrapper.click(BaseClass.driver, BaseClass.OBJECT.getProperty(""));
	}
	
	@Then("^Click on Decision Button in the Query Applicant Details Screen$")
	public void Click_on_Decision_Button_in_the_Query_Applicant_Details_Screen() throws InterruptedException
	{
		mywrapper.SwitchToWindow(BaseClass.driver, CommonBusinessLogic.ParentWindow);
		mywrapper.hardWait(5000);
		mywrapper.SwitchToDefaultWindow(BaseClass.driver);
		mywrapper.switchToFrame(BaseClass.driver, "content");
		mywrapper.hardWait(2000);
		mywrapper.click(BaseClass.driver, BaseClass.OBJECT.getProperty("Data_Entry_Decision"));
	}

}
