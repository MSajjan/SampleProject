package com.standardchartered.techm.application.glue;

import com.standardchartered.techm.application.utils.Wrapper;

import cucumber.api.java.en.Then;

public class IncomeDetailsOperationSuccessfulScreen {

	public Wrapper mywrapper= new Wrapper();
	
	@Then("^Validate the Operation Successful message is displayed and Click Go Back Button$")
	public void clickSaveinIncomeTaxDetailsScreen() throws InterruptedException
	{
		// Need to write the code for Validation
		mywrapper.click(BaseClass.driver,BaseClass.OBJECT.getProperty("goback_incomeTax"));
		mywrapper.hardWait(9000);
	}
	
	
}
