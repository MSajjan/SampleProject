package com.standardchartered.techm.application.glue;

import java.awt.Robot;
import java.awt.event.KeyEvent;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;

import com.standardchartered.techm.application.utils.Wrapper;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;

public class CreditApprovalScreen {

	
	public Wrapper mywrapper= new Wrapper();
	
/*	@Then("^Enter details in CA screen$")
	public void Enter_details_in_CA_screen() throws Exception
	{
		mywrapper.hardWait(2000);
		mywrapper.SwitchToDefaultWindow(BaseClass.driver);
		mywrapper.switchToFrame(BaseClass.driver, "content");
		System.out.println("Enter details in CA screen");
		mywrapper.javaScriptExec_SendKeys(BaseClass.driver,BaseClass.OBJECT.getProperty("Credit_Approval_Notes"),BaseClass.datamap.get(BaseClass.tempindex).get("CA_Notes"));
		mywrapper.Sendkeys_Tab(BaseClass.driver, BaseClass.OBJECT.getProperty("Credit_Approval_Notes"), Keys.TAB);
		mywrapper.clearAndSendKeys(BaseClass.driver, "//input[@name='txtAcceptanceKey']","121");
		mywrapper.hardWait(2000);
		WebElement elm1= BaseClass.driver.findElement(By.xpath(BaseClass.OBJECT.getProperty("Credit_Approval_Notes")));
		JavascriptExecutor js1 = (JavascriptExecutor) BaseClass.driver;
		js1.executeScript("return arguments[0].setAttribute('value', '"+BaseClass.datamap.get(BaseClass.tempindex).get("CA_Notes")+"')",elm1);
		mywrapper.Sendkeys_Tab(BaseClass.driver, BaseClass.OBJECT.getProperty("Credit_Approval_Notes"), Keys.TAB);	
		mywrapper.javaScriptExec_SendKeys(BaseClass.driver, "//input[@name='txtAcceptanceKey']","121");
		mywrapper.click(BaseClass.driver, "//input[@name='txtAcceptanceKey']");
		System.out.println(elm1.getAttribute("value"));
		mywrapper.clearAndSendKeys(BaseClass.driver, "//input[@name='txtAcceptanceKey']","121");
		mywrapper.Sendkeys_Tab(BaseClass.driver, BaseClass.OBJECT.getProperty("Credit_Approval_Notes"), Keys.TAB);
		mywrapper.javaScriptExec_SendKeys(BaseClass.driver, "//input[@name='txtAcceptanceKey']","121");
		BaseClass.driver.findElement(By.xpath(BaseClass.OBJECT.getProperty("Credit_Approval_Notes"))).click();
		BaseClass.driver.findElement(By.xpath(BaseClass.OBJECT.getProperty("Credit_Approval_Notes"))).clear();
		BaseClass.driver.findElement(By.xpath(BaseClass.OBJECT.getProperty("Credit_Approval_Notes"))).sendKeys(BaseClass.datamap.get(BaseClass.tempindex).get("CA_Notes"));
		BaseClass.driver.findElement(By.xpath(BaseClass.OBJECT.getProperty("Credit_Approval_Notes"))).sendKeys(Keys.TAB);
		
		
		
		mywrapper.javascriptEx_Click(BaseClass.driver, BaseClass.OBJECT.getProperty("Credit_Approval_Save"));
		mywrapper.hardWait(2000);
		mywrapper.click(BaseClass.driver, BaseClass.OBJECT.getProperty("Credit_Approval_Action"));
		mywrapper.hardWait(2000);
		mywrapper.AcceptAlertIfPresent(BaseClass.driver);
		mywrapper.hardWait(2000);
		mywrapper.SwitchToDefaultWindow(BaseClass.driver);
		mywrapper.switchToFrame(BaseClass.driver, "content");
		String Success_Text=mywrapper.getElement(BaseClass.driver, BaseClass.OBJECT.getProperty("Decision_Success")).getText();
		Assert.assertTrue("Operation Successful message is Not Displayed",Success_Text.equals("Operation Successful"));
	}*/
	

	
	@Then("^Enter details in CA screen$")
	public void Enter_details_in_CA_screen() throws Exception
	{
		mywrapper.SwitchToDefaultWindow(BaseClass.driver);
		mywrapper.switchToFrame(BaseClass.driver, "content");
		System.out.println("Enter details in CA screen");
		//mywrapper.javaScriptExec_clearAndSendKeys(BaseClass.driver,BaseClass.OBJECT.getProperty("Credit_Approval_Notes"),BaseClass.datamap.get(BaseClass.tempindex).get("CA_Notes"));
		//mywrapper.Sendkeys_Tab(BaseClass.driver, BaseClass.OBJECT.getProperty("Credit_Approval_Notes"), Keys.TAB);
		BaseClass.driver.findElement(By.xpath(BaseClass.OBJECT.getProperty("Credit_Approval_Notes"))).sendKeys("");
		Robot robot = new Robot();
		robot.keyPress(KeyEvent.VK_O);	
		robot.keyRelease(KeyEvent.VK_O);
		robot.keyPress(KeyEvent.VK_K);	
		robot.keyRelease(KeyEvent.VK_K);
		robot.keyPress(KeyEvent.VK_TAB);
		robot.keyRelease(KeyEvent.VK_TAB);
		mywrapper.javascriptEx_Click(BaseClass.driver, BaseClass.OBJECT.getProperty("Credit_Approval_Save"));
		mywrapper.hardWait(4000);
		mywrapper.SwitchToDefaultWindow(BaseClass.driver);
		mywrapper.switchToFrame(BaseClass.driver, "content");
		mywrapper.hardWait(4000);
		mywrapper.javascriptEx_Click(BaseClass.driver, BaseClass.OBJECT.getProperty("Credit_Approval_approve_action"));
		mywrapper.hardWait(2000);
		mywrapper.javascriptEx_Click(BaseClass.driver, BaseClass.OBJECT.getProperty("Credit_Approval_Action"));
		mywrapper.AcceptAlertIfPresent(BaseClass.driver);
		mywrapper.hardWait(2000);
		mywrapper.SwitchToDefaultWindow(BaseClass.driver);
		mywrapper.switchToFrame(BaseClass.driver, "content");
		String Success_Text=mywrapper.getElement(BaseClass.driver, BaseClass.OBJECT.getProperty("Decision_Success")).getText();
		Assert.assertTrue("Operation Successful message is Not Displayed",Success_Text.equals("Operation Successful"));
	}
}
