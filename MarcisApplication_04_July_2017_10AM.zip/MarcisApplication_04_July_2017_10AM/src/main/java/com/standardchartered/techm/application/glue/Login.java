package com.standardchartered.techm.application.glue;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;










import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;

import com.fasterxml.jackson.databind.deser.Deserializers.Base;
import com.standardchartered.techm.application.utils.DataHelper;
import com.standardchartered.techm.application.utils.Wrapper;

import cucumber.api.java.en.*;
	

public class Login {
	//public static WebBaseClass.driver BaseClass.driver=BaseClass.BaseClass.driver;
	int index=0;
	
	public Wrapper mywrapper= new Wrapper();
	//public List<HashMap<String,String>> BaseClass.datamap=BaseClass.datamap;
	
	
	/*@When("^Enter to the Values '(.+)' and '(.+)'$")
    public void TestLogin(String username,String password) throws Throwable 
    {
        BaseClass.driver.findElement(By.xpath(BaseClass.OBJECT.getProperty("username_textfield"))).sendKeys(username);
        BaseClass.driver.findElement(By.xpath(BaseClass.OBJECT.getProperty("password_textfield"))).sendKeys(password);
    }
	*/
	@When("^the Valid Login Details$")
    public void TestLogin2() throws Throwable 
    {
	//	 datamap = DataHelper.data(System.getProperty("user.dir")+"/src/test/resources/testData/Login.xlsx","LoginSheet1");
	    mywrapper.clearAndSendKeys(BaseClass.driver,BaseClass.OBJECT.getProperty("username_textfield"), BaseClass.datamap.get(BaseClass.tempindex).get("username"));
        mywrapper.clearAndSendKeys(BaseClass.driver,BaseClass.OBJECT.getProperty("password_textfield"), BaseClass.datamap.get(BaseClass.tempindex).get("password"));
        mywrapper.clearAndSendKeys(BaseClass.driver,BaseClass.OBJECT.getProperty("portfolio_textfield"), BaseClass.datamap.get(BaseClass.tempindex).get("portfolio"));
        mywrapper.clearAndSendKeys(BaseClass.driver,BaseClass.OBJECT.getProperty("branch_textfield"), BaseClass.datamap.get(BaseClass.tempindex).get("branch"));
        mywrapper.SelectUsingVisibleValue(BaseClass.driver,BaseClass.OBJECT.getProperty("country_textfield"), BaseClass.datamap.get(BaseClass.tempindex).get("city"));     
    }
	
	
	@Then("^click on Live chat option$")
	public void LiveChat()
	{
		mywrapper.click(BaseClass.driver, BaseClass.OBJECT.getProperty("LiveChat"));		
	}
	
	
/*	@And("^Switch to Live chat window and pass the values$")
	public void SwitchWindow()
	{
		mywrapper.NoOfWindows(BaseClass.driver, 15, 5000, 2);
		mywrapper.SwtichToWindowViaWindowTitle(BaseClass.driver, "EziBuy");
		mywrapper.clearAndSendKeys(BaseClass.driver, BaseClass.OBJECT.getProperty("ChildWindowValue"), "sak");
	}*/
	
	
	@Then("^handle the Security Warning popup$")
	public void handle_the_Security_Warning_popup() throws Throwable 
	{
		System.out.println("handle_the_Security_Warning_popup");
	Process P= Runtime.getRuntime().exec(System.getProperty("user.dir")+"\\src\\test\\resources\\AutoIt\\SecurityWarning_exe.exe");
	P.waitFor();
	Thread.sleep(2000);
	}
	
	
	@Given("^enter valid credentials$")
	public void enter_valid_credentails() throws Throwable 
	{
		System.out.println("Enter the Valid Credentials");
		mywrapper.clearAndSendKeys(BaseClass.driver,BaseClass.OBJECT.getProperty("User_ID_LoginPage"),BaseClass.datamap.get(BaseClass.tempindex).get("username"));
		mywrapper.clearAndSendKeys(BaseClass.driver,BaseClass.OBJECT.getProperty("Pwd_LoginPage"),BaseClass.datamap.get(BaseClass.tempindex).get("password"));
		mywrapper.clearAndSendKeys(BaseClass.driver,BaseClass.OBJECT.getProperty("Portfolio_LoginPage"),BaseClass.datamap.get(BaseClass.tempindex).get("Portfolio"));
		mywrapper.clearAndSendKeys(BaseClass.driver,BaseClass.OBJECT.getProperty("Branch_LoginPage"),BaseClass.datamap.get(BaseClass.tempindex).get("Branch"));
		mywrapper.SelectUsingValue(BaseClass.driver,BaseClass.OBJECT.getProperty("Country_LoginPage"),BaseClass.datamap.get(BaseClass.tempindex).get("Country"));	
		//mywrapper.click(BaseClass.driver,BaseClass.OBJECT.getProperty("home_login_submit"));
				
	}
	
	@Then("^click on Login button$")
	public void click_on_Login_button() throws InterruptedException
	{
		System.out.println("Click on Login button");
		mywrapper.click(BaseClass.driver, BaseClass.OBJECT.getProperty("Login_Button_LoginPage"));
		mywrapper.hardWait(19000);
		
	}
	
	@And("^handle expiry warning popup$")
	public void handle_expiry_warning_popup() throws Exception
	{
		System.out.println("handle expiry warning popup");
		mywrapper.AcceptAlertIfPresent(BaseClass.driver);
		mywrapper.hardWait(4000);
	}
	
	@Given("^Navigate to Individual consumer$")
	public void Navigate_to_Individual_consumer() throws InterruptedException
	{
	
		System.out.println("Click on DataEntry");
		mywrapper.hardWait(5000);
		//BaseClass.driver.switchTo().frame(0);
//		mywrapper.SwitchToDefaultWindow(BaseClass.driver);
//		mywrapper.switchToFrame(BaseClass.driver, BaseClass.OBJECT.getProperty("MainPage_Frame"));
//		mywrapper.hardWait(5000);
		//mywrapper.click(BaseClass.driver, BaseClass.OBJECT.getProperty("DataEnty_Mainpage"));
		/*mywrapper.hardWait(5000);
		
		BaseClass.driver.findElement(By.xpath("//td[@name='m12']/label")).click();
		
		mywrapper.MoveToElementAndClick(BaseClass.driver, "//td[@name='m12']/label");
		mywrapper.click(BaseClass.driver, BaseClass.OBJECT.getProperty("Individual_Consumer_Mainpage"));
		*/
	}
	
	@Given("^Navigate to match Details page$")
	public void Navigate_to_match_Details_page() throws InterruptedException
	{
		mywrapper.hardWait(9000);
		//BaseClass.driver.get("https://marcisuat.ke.standardchartered.com/Retails/lendsphere/Menu_MainPage.jsp");
		mywrapper.hardWait(5000);
		mywrapper.SwitchToDefaultWindow(BaseClass.driver);
		mywrapper.switchToFrame(BaseClass.driver, "content");
		mywrapper.hardWait(2000);
		mywrapper.SelectUsingValue(BaseClass.driver,BaseClass.OBJECT.getProperty("Title_Matching"),"Mr");
		mywrapper.javaScriptExec_clearAndSendKeys(BaseClass.driver,BaseClass.OBJECT.getProperty("FirstName_Matching"),"Sakratees");
		mywrapper.javaScriptExec_clearAndSendKeys(BaseClass.driver,BaseClass.OBJECT.getProperty("LastName_Matching"),"Ezhil");
		mywrapper.javaScriptExec_clearAndSendKeys(BaseClass.driver,BaseClass.OBJECT.getProperty("Telephone_Matching"),"12345678");
		//BaseClass.driver.findElement(By.xpath("//input[@name='msztxtLastName']")).sendKeys("Ezhil");
		//mywrapper.hardWait(5000);
//		mywrapper.click(BaseClass.driver,BaseClass.OBJECT.getProperty("Date_Of_Birth_Matching"));
//		mywrapper.hardWait(5000);
		mywrapper.click(BaseClass.driver,BaseClass.OBJECT.getProperty("Date_Of_Birth_Matching"));
		mywrapper.SwitchToWindowViaWindowTitle(BaseClass.driver, "Calendar");
		mywrapper.hardWait(8000);		
//		mywrapper.SelectUsingValue(BaseClass.driver,BaseClass.OBJECT.getProperty("Year_Matching"),"1989");
//		mywrapper.hardWait(5000);
//		mywrapper.SelectUsingValue(BaseClass.driver,BaseClass.OBJECT.getProperty("Months_Matching"),"12");
//		mywrapper.hardWait(5000);
//		mywrapper.click(BaseClass.driver,BaseClass.OBJECT.getProperty("Date_Matching"));
//		mywrapper.click(BaseClass.driver,BaseClass.OBJECT.getProperty("Telephone_Matching"));
//		mywrapper.click(BaseClass.driver,BaseClass.OBJECT.getProperty("Match_Details_Button"));
//		mywrapper.hardWait(5000);
	}
	
	@Given("^Product detail page$")
	public void Product_detail_page() throws InterruptedException
	{
		
		
		mywrapper.hardWait(9000);
		mywrapper.hardWait(9000);
		mywrapper.hardWait(9000);
		mywrapper.SwitchToDefaultWindow(BaseClass.driver);
		mywrapper.switchToFrame(BaseClass.driver, "content");
		mywrapper.hardWait(5000);
		
		
		
		
		mywrapper.SelectUsingValue(BaseClass.driver, BaseClass.OBJECT.getProperty("Marital_Status_Application_Details"), "S");
		mywrapper.SelectUsingValue(BaseClass.driver, BaseClass.OBJECT.getProperty("Occupation_Application_Details"), "ACC");
		mywrapper.SelectUsingValue(BaseClass.driver, BaseClass.OBJECT.getProperty("Employment_Type_Application_Details"), "PERM");
		mywrapper.SelectUsingValue(BaseClass.driver, BaseClass.OBJECT.getProperty("Nationality_Application_Details"), "KENYAN");
		mywrapper.SelectUsingValue(BaseClass.driver, BaseClass.OBJECT.getProperty("CDD_Risk_Code_Application_Details"), "EDD");
		mywrapper.SelectUsingValue(BaseClass.driver, BaseClass.OBJECT.getProperty("ID_Type_Code_Application_Details"), "Voters ID");
		mywrapper.SelectUsingValue(BaseClass.driver, BaseClass.OBJECT.getProperty("Qualification_Application_Details"), "BDEG");
		mywrapper.SelectUsingValue(BaseClass.driver, BaseClass.OBJECT.getProperty("Country_of_Birth_Application_Details"), "KENYAN");
		mywrapper.javaScriptExec_clearAndSendKeys(BaseClass.driver, BaseClass.OBJECT.getProperty("Passport_No_Application_Details"), "H2718386");
		mywrapper.javaScriptExec_clearAndSendKeys(BaseClass.driver, BaseClass.OBJECT.getProperty("Email_Contact_Application_Details"), "adf@gmail.com");
		mywrapper.javaScriptExec_clearAndSendKeys(BaseClass.driver, BaseClass.OBJECT.getProperty("eBBs_RelationNo_Application_Details"), "1");
		mywrapper.javaScriptExec_clearAndSendKeys(BaseClass.driver, BaseClass.OBJECT.getProperty("Dependants_Application_Details"), "2");
		mywrapper.javaScriptExec_clearAndSendKeys(BaseClass.driver, BaseClass.OBJECT.getProperty("Children_Application_Details"), "2");
		mywrapper.javaScriptExec_clearAndSendKeys(BaseClass.driver, BaseClass.OBJECT.getProperty("ID_Details_Application_Details"), "FE4536");
		mywrapper.click(BaseClass.driver, BaseClass.OBJECT.getProperty("US_Resident_Application_Details"));
		mywrapper.click(BaseClass.driver, BaseClass.OBJECT.getProperty("US_Citizen_Application_Details"));
		mywrapper.click(BaseClass.driver, BaseClass.OBJECT.getProperty("Green_card_Application_Details"));
		
		mywrapper.javaScriptExec_clearAndSendKeys(BaseClass.driver, BaseClass.OBJECT.getProperty("Dealer_Time_hr_Application_Details"), "12");
		mywrapper.javaScriptExec_clearAndSendKeys(BaseClass.driver, BaseClass.OBJECT.getProperty("Dealer_Time_mm_Application_Details"), "12");
		mywrapper.javaScriptExec_clearAndSendKeys(BaseClass.driver, BaseClass.OBJECT.getProperty("LoanCenter_Time_hr_Application_Details"), "0");
		mywrapper.javaScriptExec_clearAndSendKeys(BaseClass.driver, BaseClass.OBJECT.getProperty("LoanCenter_Time_mm_Application_Details"), "12");
		mywrapper.javaScriptExec_clearAndSendKeys(BaseClass.driver, BaseClass.OBJECT.getProperty("Children_Application_Details"), "2");
		
		
	
		mywrapper.click(BaseClass.driver,BaseClass.OBJECT.getProperty("Product_Detail_Button"));
		/*WebDriver driver1= BaseClass.driver;
		((JavascriptExecutor)driver1).executeScript("lfnProductDetails();");*/
		mywrapper.hardWait(9000);
		mywrapper.hardWait(9000);
		mywrapper.SwitchToWindowViaWindowTitle(BaseClass.driver, "Product Details");
		mywrapper.hardWait(5000);
		mywrapper.SelectUsingValue(BaseClass.driver,BaseClass.OBJECT.getProperty("Emp_code_dw"),"2166--STRATHMORE UNIVERSITY");
		mywrapper.hardWait(5000);
		mywrapper.click(BaseClass.driver,BaseClass.OBJECT.getProperty("Fetch_EmpCode"));
		mywrapper.hardWait(5000);
		mywrapper.SelectUsingValue(BaseClass.driver,BaseClass.OBJECT.getProperty("Product_code_dw"),"KBDAI--SSFULL BUNDLE APPROVED CO DAS TOP-UP");
		mywrapper.hardWait(5000);
		mywrapper.click(BaseClass.driver,BaseClass.OBJECT.getProperty("Fetch_ProductCode"));
		mywrapper.hardWait(5000);
		mywrapper.SelectUsingValue(BaseClass.driver,BaseClass.OBJECT.getProperty("Plan_code_dw"),"PPL167904--Priority CAT B");
		mywrapper.hardWait(5000);
		mywrapper.click(BaseClass.driver,BaseClass.OBJECT.getProperty("GoToMainScreen"));
		
	}
	
	@Then("^click on Logout$")
	public void click_on_Logout() throws InterruptedException
	{
		System.out.println("Logout");
		mywrapper.SwitchToDefaultWindow(BaseClass.driver);
		mywrapper.switchToFrame(BaseClass.driver, "menu");
		mywrapper.hardWait(1000);
		mywrapper.click(BaseClass.driver, BaseClass.OBJECT.getProperty("Logout_Button"));
		mywrapper.hardWait(2000);
		mywrapper.SwitchToDefaultWindow(BaseClass.driver);
		
	}
	
	@When("^Logout$")
 	public void logout() throws IOException, InterruptedException
 	{
 		boolean visi_logout=false;
 		mywrapper.SwitchToDefaultWindow(BaseClass.driver);
 		if(mywrapper.IsElementPresentQuick(BaseClass.driver,BaseClass.OBJECT.getProperty("logOut_xpath")))
 		{
 			mywrapper.click(BaseClass.driver,BaseClass.OBJECT.getProperty("logOut_xpath"));
 			System.out.println("Sucessfully Clicked the Logout Link");
 		}
 		
 		
 		
 	}
	
	/*@Given("^Enter the IncomeTax Details Screen$")
	public void enterIncomeTaxDetailsScreen() throws InterruptedException
	{
		
		
		mywrapper.hardWait(9000);
		mywrapper.SwitchToDefaultWindow(BaseClass.driver);
		mywrapper.switchToFrame(BaseClass.driver, "content");
		mywrapper.hardWait(5000);
		mywrapper.click(BaseClass.driver,"//input[@name='cmdIncomeDetails']");
		mywrapper.hardWait(9000);
		
		mywrapper.SwitchToWindowViaWindowTitle(BaseClass.driver, "Applicant Income Details");
		mywrapper.hardWait(5000);
		
		mywrapper.javaScriptExec_clearAndSendKeys(BaseClass.driver, BaseClass.OBJECT.getProperty("salaryincome_incomeTax"), "3000000");
		mywrapper.javaScriptExec_clearAndSendKeys(BaseClass.driver, BaseClass.OBJECT.getProperty("commearn_incomeTax"), "100000");
		mywrapper.javaScriptExec_clearAndSendKeys(BaseClass.driver, BaseClass.OBJECT.getProperty("investments_incomeTax"), "10000");
		mywrapper.javaScriptExec_clearAndSendKeys(BaseClass.driver, BaseClass.OBJECT.getProperty("property_incomeTax"), "50000");
		mywrapper.javaScriptExec_clearAndSendKeys(BaseClass.driver, BaseClass.OBJECT.getProperty("other_incomeTax"), "9000");
		mywrapper.javaScriptExec_clearAndSendKeys(BaseClass.driver, BaseClass.OBJECT.getProperty("bonus_incomeTax"), "50000");
		
		
	}
	*/
	@Given("^Navigate to Application List DD Screen$")
	public void Navigate_ApplicationList_DD_Screen() throws InterruptedException
	{
		mywrapper.SwitchToDefaultWindow(BaseClass.driver);
		mywrapper.switchToFrame(BaseClass.driver, "menu");
		mywrapper.hardWait(5000);
		mywrapper.click(BaseClass.driver,"//label[text()='Application Lists']");
		mywrapper.hardWait(5000);
		mywrapper.SwitchToDefaultWindow(BaseClass.driver);
		mywrapper.switchToFrame(BaseClass.driver, "content");
		mywrapper.click(BaseClass.driver,"//div[text()='Application List - DD']");
		mywrapper.hardWait(5000);
		mywrapper.SwitchToDefaultWindow(BaseClass.driver);
		mywrapper.switchToFrame(BaseClass.driver, "content");
		//mywrapper.hardWait(5000);
		mywrapper.waitForElementClickable(BaseClass.driver, "//a[text()='PLNAI271447']", 120, 10);
		mywrapper.click(BaseClass.driver, "//a[text()='PLNAI271447']");
		mywrapper.hardWait(15000);
		mywrapper.SwitchToDefaultWindow(BaseClass.driver);
		mywrapper.hardWait(1000);
		mywrapper.switchToFrame(BaseClass.driver, "content");
		mywrapper.hardWait(5000);
		mywrapper.waitForElementClickable(BaseClass.driver, "//a[text()='KEN234939']", 120, 10);
		mywrapper.click(BaseClass.driver, "//a[text()='KEN234939']");
		mywrapper.hardWait(5000);
		mywrapper.waitForElementClickable(BaseClass.driver, "//input[@name='cmdBankDetails']", 120, 10);
		mywrapper.click(BaseClass.driver, "//input[@name='cmdBankDetails']");
		
		mywrapper.SwitchToDefaultWindow(BaseClass.driver);
		mywrapper.hardWait(10000);
		mywrapper.SwitchToWindowViaWindowTitle(BaseClass.driver, "Applicant Bank Details");
		mywrapper.waitForElementClickable(BaseClass.driver, "//input[@name='cmdAdd']", 120, 10);
		mywrapper.click(BaseClass.driver, "//input[@name='cmdAdd']");
		mywrapper.waitForElementClickable(BaseClass.driver, "//input[@submitName='imgBankCode']", 120, 10);
		mywrapper.click(BaseClass.driver, "//input[@submitName='imgBankCode']");
		mywrapper.SwitchToWindowViaWindowTitle(BaseClass.driver, "BANK");	
	}
	
	
//	@Then("^Verify Operation Successful message and click on Go Back$")
//	public void Navigate_to_Application_Details_Operation_Screen()
//	{
//		String Success_Text=mywrapper.getElement(BaseClass.driver, BaseClass.OBJECT.getProperty("Application_Details_Operation")).getText();
//	if(Success_Text.equals("Operation Successful"))
//	{
//		mywrapper.click(BaseClass.driver, BaseClass.OBJECT.getProperty("Application_Details_Go_Back"));
//	}
//	}
	
	@Given("^Navigate to \"([^\"]*)\" and \"([^\"]*)\"$")
	public void Navigate_to_Payment_and_DRE_Automatic(String Menu,String SubMenu) throws InterruptedException
	{
		mywrapper.SwitchToDefaultWindow(BaseClass.driver);
		mywrapper.switchToFrame(BaseClass.driver, "menu");
		mywrapper.hardWait(2000);
		mywrapper.click(BaseClass.driver,BaseClass.OBJECT.getProperty(Menu));
		mywrapper.hardWait(2000);
		mywrapper.SwitchToDefaultWindow(BaseClass.driver);
		mywrapper.switchToFrame(BaseClass.driver, "content");
		mywrapper.click(BaseClass.driver,BaseClass.OBJECT.getProperty(SubMenu));
		mywrapper.hardWait(2000);
	}
	
	@Given("^Navigate to DRE Entry Automatic$")
	public void NavigatetoDREEntryAutomatic() throws InterruptedException
	{mywrapper.hardWait(5000);
		
		mywrapper.SwitchToDefaultWindow(BaseClass.driver);
		mywrapper.switchToFrame(BaseClass.driver, "menu");
		mywrapper.hardWait(2000);
		mywrapper.click(BaseClass.driver,BaseClass.OBJECT.getProperty("dreautomatic_payment_mode"));
		mywrapper.hardWait(2000);
		mywrapper.SwitchToDefaultWindow(BaseClass.driver);
		mywrapper.switchToFrame(BaseClass.driver, "content");
		mywrapper.click(BaseClass.driver,BaseClass.OBJECT.getProperty("dreautomatic_dre_entry_automatic"));
		mywrapper.hardWait(2000);
		
	}
	
	@Then("^Enter the Automatic entry for the ApplicationID$")
	public void Enter_the_Automatic_entry_for_the_ApplicationID() throws InterruptedException
	{
		
		mywrapper.hardWait(5000);
		mywrapper.SwitchToDefaultWindow(BaseClass.driver);
		mywrapper.switchToFrame(BaseClass.driver, "content");
		mywrapper.hardWait(5000);
		/*mywrapper.SelectUsingValue(BaseClass.driver, BaseClass.OBJECT.getProperty("dreautomatic_Voucher_Type"), "CRV");
		mywrapper.SelectUsingValue(BaseClass.driver, BaseClass.OBJECT.getProperty("dreautomatic_Instrument_type"), "CA");
		mywrapper.SelectUsingValue(BaseClass.driver, BaseClass.OBJECT.getProperty("dreautomatic_Currency_type"), "01");
		mywrapper.click(BaseClass.driver, BaseClass.OBJECT.getProperty("dreautomatic_Add_row_button"));
		mywrapper.SwitchToDefaultWindow(BaseClass.driver);
		mywrapper.switchToFrame(BaseClass.driver, "content");
		mywrapper.javaScriptExec_clearAndSendKeys(BaseClass.driver, BaseClass.OBJECT.getProperty("dreautomatic_aggrement_no"), "20300010033702");
		mywrapper.click(BaseClass.driver, BaseClass.OBJECT.getProperty("dreautomatic_fetch_button"));
		
		mywrapper.javaScriptExec_clearAndSendKeys(BaseClass.driver, BaseClass.OBJECT.getProperty("dreautomatic_amount_apportioned"), "1000.00");
		
		mywrapper.javaScriptExec_clearAndSendKeys(BaseClass.driver, BaseClass.OBJECT.getProperty("dreautomatic_Instrument_Amount"), "1000.00");
		//mywrapper.click(BaseClass.driver, BaseClass.OBJECT.getProperty("dreautomatic_save_button"));
		mywrapper.hardWait(4000);
		*/		
		
		mywrapper.SelectUsingValue(BaseClass.driver, BaseClass.OBJECT.getProperty("dreautomatic_Voucher_Type"), BaseClass.datamap.get(BaseClass.tempindex).get("VoucherType"));
		mywrapper.SelectUsingValue(BaseClass.driver, BaseClass.OBJECT.getProperty("dreautomatic_Instrument_type"), BaseClass.datamap.get(BaseClass.tempindex).get("InstrumentType"));
		mywrapper.SelectUsingValue(BaseClass.driver, BaseClass.OBJECT.getProperty("dreautomatic_Currency_type"), BaseClass.datamap.get(BaseClass.tempindex).get("Currency"));
		
		mywrapper.click(BaseClass.driver, BaseClass.OBJECT.getProperty("dreautomatic_Add_row_button"));
		mywrapper.SwitchToDefaultWindow(BaseClass.driver);
		mywrapper.switchToFrame(BaseClass.driver, "content");
		mywrapper.javaScriptExec_clearAndSendKeys(BaseClass.driver, BaseClass.OBJECT.getProperty("dreautomatic_aggrement_no"), BaseClass.datamap.get(BaseClass.tempindex).get("AggrementNo"));
		mywrapper.click(BaseClass.driver, BaseClass.OBJECT.getProperty("dreautomatic_fetch_button"));
		
		mywrapper.javaScriptExec_clearAndSendKeys(BaseClass.driver, BaseClass.OBJECT.getProperty("dreautomatic_amount_apportioned"), BaseClass.datamap.get(BaseClass.tempindex).get("AmountApportioned"));
		
		mywrapper.javaScriptExec_clearAndSendKeys(BaseClass.driver, BaseClass.OBJECT.getProperty("dreautomatic_Instrument_Amount"), BaseClass.datamap.get(BaseClass.tempindex).get("InstrumentAmount"));
		mywrapper.click(BaseClass.driver, BaseClass.OBJECT.getProperty("dreautomatic_save_button"));
		mywrapper.hardWait(4000);
		
	}
	
	@Then("^Go to Decision Screen$")
	public void Go_to_Decision_Screen() throws InterruptedException
	{
		mywrapper.hardWait(2000);
		mywrapper.SwitchToDefaultWindow(BaseClass.driver);
		mywrapper.switchToFrame(BaseClass.driver, "menu");
		mywrapper.hardWait(8000);
		mywrapper.click(BaseClass.driver,BaseClass.OBJECT.getProperty("Application_list_Menu"));
		mywrapper.hardWait(4000);
		mywrapper.SwitchToDefaultWindow(BaseClass.driver);
		mywrapper.switchToFrame(BaseClass.driver, "content");
		mywrapper.click(BaseClass.driver,BaseClass.OBJECT.getProperty("DD_SubMenu"));
		mywrapper.hardWait(2000);
		mywrapper.SwitchToDefaultWindow(BaseClass.driver);
		mywrapper.switchToFrame(BaseClass.driver, "content");
		mywrapper.hardWait(2000);
		mywrapper.click(BaseClass.driver,BaseClass.OBJECT.getProperty("Application_DD_No"));
		mywrapper.hardWait(4000);
		mywrapper.SwitchToDefaultWindow(BaseClass.driver);
		mywrapper.switchToFrame(BaseClass.driver, "content");
		mywrapper.click(BaseClass.driver,BaseClass.OBJECT.getProperty("Data_Entry_Decision"));
		mywrapper.hardWait(4000); 	
		mywrapper.SwitchToDefaultWindow(BaseClass.driver);
		mywrapper.switchToFrame(BaseClass.driver, "content");
		mywrapper.hardWait(4000);
		mywrapper.click(BaseClass.driver, BaseClass.OBJECT.getProperty("Decision_Screen_View_Decision"));
		mywrapper.hardWait(4000); 	
		mywrapper.SwitchToDefaultWindow(BaseClass.driver);
		mywrapper.switchToFrame(BaseClass.driver, "content");
		mywrapper.click(BaseClass.driver, BaseClass.OBJECT.getProperty("Decision_Screen_Forward"));
		mywrapper.hardWait(4000); 	
		mywrapper.click(BaseClass.driver, BaseClass.OBJECT.getProperty("Decision_Screen_Action"));
		mywrapper.hardWait(8000); 
		String Success_Text=mywrapper.getElement(BaseClass.driver, BaseClass.OBJECT.getProperty("Decision_Success")).getText();
		if(Success_Text.equals("Operation Successful"))
		{
			System.out.println("Operation Successful");
		}
		
		mywrapper.hardWait(4000);
	}
	
	@Then("^Add Loan Details$")
	public void Add_Loan_Details() throws InterruptedException
	{
		mywrapper.SwitchToDefaultWindow(BaseClass.driver);
		mywrapper.switchToFrame(BaseClass.driver, "menu");
		mywrapper.hardWait(4000);
		mywrapper.click(BaseClass.driver,BaseClass.OBJECT.getProperty("Application_list_Menu"));
		mywrapper.hardWait(4000);
		mywrapper.SwitchToDefaultWindow(BaseClass.driver);
		mywrapper.switchToFrame(BaseClass.driver, "content");
		mywrapper.click(BaseClass.driver,BaseClass.OBJECT.getProperty("DD_SubMenu"));
		mywrapper.hardWait(2000);
		mywrapper.SwitchToDefaultWindow(BaseClass.driver);
		mywrapper.switchToFrame(BaseClass.driver, "content");
		mywrapper.click(BaseClass.driver,BaseClass.OBJECT.getProperty("Application_DD_No"));
		mywrapper.hardWait(4000);
		mywrapper.SwitchToDefaultWindow(BaseClass.driver);
		mywrapper.switchToFrame(BaseClass.driver, "content");
		//mywrapper.click(BaseClass.driver,BaseClass.OBJECT.getProperty("Data_Entry_Loan_Details"));
		mywrapper.hardWait(4000); 		
		//mywrapper.NoOfWindows(BaseClass.driver, 60, 5000, 2);
		//mywrapper.SwitchToWindow(BaseClass.driver,1);
//		//mywrapper.SwitchToWindowViaWindowTitle(BaseClass.driver, "Loan Details");
		//mywrapper.hardWait(12000); 	
		mywrapper.clearAndSendKeys(BaseClass.driver,BaseClass.OBJECT.getProperty("Applied_Loan_Amt_Loan_Details"), "560000");
		mywrapper.clearAndSendKeys(BaseClass.driver,BaseClass.OBJECT.getProperty("Applied_Interest_Rate_Loan_Details"), "7");
		mywrapper.clearAndSendKeys(BaseClass.driver,BaseClass.OBJECT.getProperty("Applied_Tenor_Loan_Details"), "15");
		mywrapper.SelectUsingValue(BaseClass.driver,BaseClass.OBJECT.getProperty("Payment_Type_Loan_Details"), "AUT");
		mywrapper.Keys_clearAndSendKeys(BaseClass.driver,BaseClass.OBJECT.getProperty("Payment_Type_Loan_Details"),Keys.TAB);
		mywrapper.hardWait(2000);
		mywrapper.click(BaseClass.driver,BaseClass.OBJECT.getProperty("Fetch_Loan_Details"));
		mywrapper.hardWait(2000);
		mywrapper.click(BaseClass.driver,BaseClass.OBJECT.getProperty("Calculate_Loan_Details"));
		mywrapper.hardWait(2000);
		mywrapper.click(BaseClass.driver,BaseClass.OBJECT.getProperty("Save_Loan_Details"));
		mywrapper.hardWait(6000);
	}
	
	
	@Then("^navigate to Application List DB$")
	public void navigate_to_Application_List_DB() throws InterruptedException
	{
		mywrapper.SwitchToDefaultWindow(BaseClass.driver);
		mywrapper.switchToFrame(BaseClass.driver, "menu");
		mywrapper.hardWait(4000);
		mywrapper.click(BaseClass.driver,BaseClass.OBJECT.getProperty("Application_list_Menu"));
		mywrapper.hardWait(4000);
		mywrapper.SwitchToDefaultWindow(BaseClass.driver);
		mywrapper.switchToFrame(BaseClass.driver, "content");
		mywrapper.click(BaseClass.driver,BaseClass.OBJECT.getProperty("Application_list_DB_SubMenu"));
		mywrapper.hardWait(2000);
		mywrapper.hardWait(2000);
		mywrapper.SwitchToDefaultWindow(BaseClass.driver);
		mywrapper.switchToFrame(BaseClass.driver, "content");
		mywrapper.click(BaseClass.driver,BaseClass.OBJECT.getProperty("Application_DB1_No"));
		mywrapper.hardWait(9000);
		mywrapper.SwitchToDefaultWindow(BaseClass.driver);
		mywrapper.switchToFrame(BaseClass.driver, "content");
		mywrapper.hardWait(2000);
		mywrapper.javaScriptExec_clearAndSendKeys(BaseClass.driver,BaseClass.OBJECT.getProperty("Disbursement_Amount"), "345092");
		mywrapper.SelectUsingValue(BaseClass.driver,BaseClass.OBJECT.getProperty("Disbusement_Account_Type"), "GL");
		mywrapper.hardWait(2000);
		BaseClass.driver.findElement(By.xpath(BaseClass.OBJECT.getProperty("Disbusement_Account_Type"))).sendKeys(Keys.TAB);
		mywrapper.hardWait(2000);
		mywrapper.javaScriptExec_clearAndSendKeys(BaseClass.driver,BaseClass.OBJECT.getProperty("Disbusement_GL_Code"), "0134543343214");
		mywrapper.hardWait(2000);
		
		mywrapper.javaScriptExec_clearAndSendKeys(BaseClass.driver,BaseClass.OBJECT.getProperty("Disbusement_Repayment_Acc_No"), "4534543343214");
		mywrapper.SelectUsingValue(BaseClass.driver,BaseClass.OBJECT.getProperty("Disbusement_Business_Segment"), "0");
		mywrapper.SelectUsingValue(BaseClass.driver,BaseClass.OBJECT.getProperty("Disbusement_Stmt_Frequency"), "H");
		mywrapper.hardWait(2000);
		mywrapper.javaScriptExec_clearAndSendKeys(BaseClass.driver,BaseClass.OBJECT.getProperty("Disbusement_GL_Code"), "5645");
		mywrapper.javaScriptExec_clearAndSendKeys(BaseClass.driver,BaseClass.OBJECT.getProperty("Disbusement_EBBS_Acc_No"), "123");
	}
	
	
	
	@Then("^navigate to Application List CA$")
	public void navigate_to_Application_List() throws InterruptedException
	{
		mywrapper.SwitchToDefaultWindow(BaseClass.driver);
		mywrapper.switchToFrame(BaseClass.driver, "menu");
		mywrapper.hardWait(2000);
		mywrapper.click(BaseClass.driver,BaseClass.OBJECT.getProperty("Application_list_Menu"));
		mywrapper.hardWait(2000);
		mywrapper.SwitchToDefaultWindow(BaseClass.driver);
		mywrapper.switchToFrame(BaseClass.driver, "content");
		mywrapper.click(BaseClass.driver,BaseClass.OBJECT.getProperty("Application_list_SubMenu"));
		mywrapper.hardWait(9000);
		mywrapper.hardWait(2000);
		mywrapper.SwitchToDefaultWindow(BaseClass.driver);
		mywrapper.switchToFrame(BaseClass.driver, "content");
		mywrapper.hardWait(9000);
		mywrapper.hardWait(2000);
		mywrapper.SwitchToDefaultWindow(BaseClass.driver);
		mywrapper.switchToFrame(BaseClass.driver, "content");
		mywrapper.javaScriptExec_clearAndSendKeys(BaseClass.driver,BaseClass.OBJECT.getProperty("Application_Text_Area"), "ok");
		//mywrapper.hardWait(3000);
//		mywrapper.highlightElement(BaseClass.driver,BaseClass.OBJECT.getProperty("Application_Click"));
		//BaseClass.driver.findElement(By.xpath("//textarea[@name='mszTxtNotes']")).sendKeys(Keys.TAB);
		//mywrapper.hardWait(3000);
		//mywrapper.clearAndSendKeys(BaseClass.driver,BaseClass.OBJECT.getProperty("Application_Click")," ");
		//mywrapper.ElementKeyDown(BaseClass.driver,BaseClass.OBJECT.getProperty("Application_Text_Area"), Keys.TAB);
		//mywrapper.KeyUP(BaseClass.driver, Keys.TAB);
		mywrapper.hardWait(3000);	
		//mywrapper.click(BaseClass.driver,BaseClass.OBJECT.getProperty("Application_Save"));
		mywrapper.hardWait(9000);
		
		
	}
	
	
	
}

