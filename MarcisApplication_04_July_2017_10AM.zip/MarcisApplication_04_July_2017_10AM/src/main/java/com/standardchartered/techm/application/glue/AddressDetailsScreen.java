package com.standardchartered.techm.application.glue;

import com.standardchartered.techm.application.utils.Wrapper;

import cucumber.api.java.en.And;

public class AddressDetailsScreen {

	
	public Wrapper mywrapper= new Wrapper();
	
	@And("^Enter details in Address Details page$")
	public void Enter_details_in_Address_Details_page() throws Exception
	{
		mywrapper.hardWait(8000);
		mywrapper.SwitchToWindowViaWindowTitle(BaseClass.driver, "Address Details");
		mywrapper.hardWait(2000);
		System.out.println("Enter Address Details");
		mywrapper.click(BaseClass.driver,BaseClass.OBJECT.getProperty("Postal_Address1_Address_Details"));
		mywrapper.clearAndSendKeys(BaseClass.driver,BaseClass.OBJECT.getProperty("Postal_Address1_Address_Details"),BaseClass.datamap.get(BaseClass.tempindex).get("Postal_Address1"));
		mywrapper.SelectUsingValue(BaseClass.driver,BaseClass.OBJECT.getProperty("Postal_Country_Address_Details"),BaseClass.datamap.get(BaseClass.tempindex).get("Postal_Country"));
		mywrapper.clearAndSendKeys(BaseClass.driver,BaseClass.OBJECT.getProperty("Postal_City_Address_Details"),BaseClass.datamap.get(BaseClass.tempindex).get("Postal_City"));
		mywrapper.clearAndSendKeys(BaseClass.driver,BaseClass.OBJECT.getProperty("Resi_Address1_Address_Details"),BaseClass.datamap.get(BaseClass.tempindex).get("Resi_Address1"));
		mywrapper.SelectUsingValue(BaseClass.driver,BaseClass.OBJECT.getProperty("Resi_Country_Address_Details"),BaseClass.datamap.get(BaseClass.tempindex).get("Resi_Country"));
		mywrapper.clearAndSendKeys(BaseClass.driver,BaseClass.OBJECT.getProperty("Resi_Phone_Address_Details"),BaseClass.datamap.get(BaseClass.tempindex).get("Resi_Phone"));
		mywrapper.SelectUsingValue(BaseClass.driver,BaseClass.OBJECT.getProperty("House_Ownership_Address_Details"),BaseClass.datamap.get(BaseClass.tempindex).get("House_Ownership"));
		mywrapper.clearAndSendKeys(BaseClass.driver,BaseClass.OBJECT.getProperty("Cost_Accomodation_Address_Details"),BaseClass.datamap.get(BaseClass.tempindex).get("Cost_Of_Accomodation"));
		mywrapper.clearAndSendKeys(BaseClass.driver,BaseClass.OBJECT.getProperty("Resi_City_Address_Details"),BaseClass.datamap.get(BaseClass.tempindex).get("Resi_City"));
		mywrapper.clearAndSendKeys(BaseClass.driver,BaseClass.OBJECT.getProperty("Stayed_Years_Address_Details"),BaseClass.datamap.get(BaseClass.tempindex).get("Stayed_years"));
		mywrapper.click(BaseClass.driver, BaseClass.OBJECT.getProperty("Save_Address_Details"));
		mywrapper.hardWait(10000);
		mywrapper.close(BaseClass.driver);
		
	}
}
