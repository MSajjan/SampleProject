package com.standardchartered.techm.application.glue;

import gherkin.formatter.model.Feature;
import gherkin.formatter.model.Step;

import java.awt.Dimension;
import java.awt.GraphicsConfiguration;
import java.awt.GraphicsEnvironment;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import javax.imageio.ImageIO;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.Alert;
import org.openqa.selenium.Capabilities;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.UnexpectedAlertBehaviour;
import org.openqa.selenium.UnhandledAlertException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.htmlunit.HtmlUnitDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.internal.ElementScrollBehavior;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;

import static org.monte.media.AudioFormatKeys.*;
import static org.monte.media.VideoFormatKeys.*;

import org.monte.media.Format;
import org.monte.media.math.Rational;
import org.monte.screenrecorder.ScreenRecorder;

import com.standardchartered.techm.application.utils.DataHelper;
import com.standardchartered.techm.application.utils.SpecializedScreenRecorder;
import com.standardchartered.techm.application.utils.Wrapper;

import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import cucumber.runtime.model.StepContainer;


public class BaseClass 
{
	Wrapper mywrap= new Wrapper();
	String CurrentMarket;
	int index=0;
	public static int tempindex;
	public static List<HashMap<String,String>> datamap;
	private Logger oLog = Logger.getLogger(BaseClass.class);
	private ScreenRecorder screenRecorder;
	public static WebDriver driver;
	public static String testResultsFIle;
//	public List<HashMap<String,String>> datamap;
	
	File file,file2;
	public static Properties CONFIG ;
	public static Properties OBJECT;
	public BaseClass()
	{
		PropertyConfigurator.configure(System.getProperty("user.dir")+"/src/main/java/com/standardchartered/techm/application/config/log4j.properties");
		file = new File(System.getProperty("user.dir")+"/src/main/java/com/standardchartered/techm/application/config/config.properties");
		file2 = new File(System.getProperty("user.dir")+"/src/test/resources/Applicationconfig/object.properties");
		FileInputStream fis = null;
		FileInputStream fis2 = null;
		try {
			fis = new FileInputStream(file);
			fis2 = new FileInputStream(file2);
		} catch (FileNotFoundException e) {

			e.printStackTrace();
		}
		CONFIG = new Properties();
		OBJECT= new Properties();
		try {
			CONFIG.load(fis);
			OBJECT.load(fis2);
		} catch (IOException e) {

			e.printStackTrace();
		}

	}
	


	
		
	
    public static String getCurrentDateTime() {

		DateFormat dateFormat = new SimpleDateFormat("_yyyy-MM-dd_HH-mm-ss");
		Calendar cal = Calendar.getInstance();
		String time = "" + dateFormat.format(cal.getTime());
		return time;
	}

	public static String getCurrentDate() {
		return getCurrentDateTime();
	}
    
	public WebDriver standAloneStepUp(String bType) throws Exception {
		try {
			oLog.info(bType);

			switch (bType) {

			case "Chrome":
				driver= getChromeDriver(getChromeCapabilities());
				return driver;
			case "Firefox":
				driver= getFirefoxDriver(getFirefoxCapabilities());
				return driver;

			case "ie":
			case "IE":
			//	driver= getIExplorerDriver(getIExplorerCapabilities());
				driver= getIExplorerDriver(getIExplorerCapabilities());
				return driver;
				

			default:
				/*throw new NoSutiableDriverFoundException(" Driver Not Found : "
						+ ObjectRepo.reader.getBrowser());*/
				return driver;
			}
		} catch (Exception e) {
			oLog.equals(e);
			throw e;
		}
	}
	
	@Before
	public void before() throws Exception {
		
		setUpDriver(CONFIG.getProperty("Browser"));
		oLog.info(CONFIG.getProperty("Browser"));
		startRecording();
	}

	@After
	public void after(Scenario scenario) throws Exception {
		tearDownDriver(scenario);
		oLog.info("*******Completed Scenerio**********");
		stopRecording();
	}
	


	public void setUpDriver(String bType) throws Exception 
	{
		driver = standAloneStepUp(bType);
		oLog.debug("InitializeWebDrive : " + driver.hashCode());
		System.out.println("InitializeWebDrive : " + driver.hashCode());
		driver.manage().deleteAllCookies();
		//driver.manage().timeouts().pageLoadTimeout(Long.parseLong(CONFIG.getProperty("PageLoadTimeOut")),TimeUnit.SECONDS);
		//driver.manage().timeouts().implicitlyWait(Long.parseLong(CONFIG.getProperty("ImplcitWait")),TimeUnit.SECONDS);
		mywrap.setImplicitWait(driver, Long.parseLong(CONFIG.getProperty("ImplcitWait")), TimeUnit.SECONDS);
		driver.manage().window().maximize();
	}

	public void tearDownDriver(Scenario scenario) throws Exception 
	{

		try 
		{
			if (driver != null) 
			{

				if(scenario.isFailed())
				{
					scenario.write(takeScreenShot(scenario.getName()));
				}
				driver.quit();
				oLog.info("Shutting Down the driver");
			}
			driver = null;
		}
		catch (org.openqa.selenium.UnhandledAlertException e) 
		{             
			File destDir = new File(CONFIG.getProperty("ScreenshotLocation")+getCurrentDate());
			if (!destDir.exists())
				destDir.mkdir();

			String destPath = destDir.getAbsolutePath()+ System.getProperty("file.separator") + scenario.getName() + ".jpg";
			BufferedImage image = new Robot().createScreenCapture(new Rectangle(Toolkit.getDefaultToolkit().getScreenSize()));

			ImageIO.write(image, "png", new File(destPath)); 
			System.out.println("The Robo Class Screenshot Location is \t:\t["+destPath+"]");
			oLog.error("The Robo Class Screenshot Location is \t:\t["+destPath+"]");
			Alert alert = driver.switchTo().alert(); 
			String alertText = alert.getText().trim();
			oLog.error("Alert Present and the text Present in the Alert Popup window ["+ alertText+"]");
			alert.accept();
			driver.switchTo().defaultContent();
			if(scenario.isFailed())
			{
				scenario.write(destPath);
			}
			driver.quit();
			oLog.info("Shutting Down the driver");

		}
		catch (Exception e) 
		{
			oLog.error(e);
			throw e;
		}
	}
    
	
	
	public Capabilities getChromeCapabilities() {
		ChromeOptions option = new ChromeOptions();
		option.addArguments("start-maximized");
		option.addArguments("--test-type");
		DesiredCapabilities chrome = DesiredCapabilities.chrome();
		chrome.setJavascriptEnabled(true);
		chrome.setCapability(ChromeOptions.CAPABILITY, option);
		return chrome;
	}

	public WebDriver getChromeDriver(Capabilities cap) {
		System.setProperty("webdriver.chrome.driver",System.getProperty("user.dir")+"/drivers/chrome/2.26/chromedriver.exe");
		return new ChromeDriver(cap);
	}
    
	
	
	public Capabilities getIExplorerCapabilities() {
		DesiredCapabilities cap = DesiredCapabilities.internetExplorer();
		cap.setCapability(CapabilityType.BROWSER_NAME, "IE");
		cap.setCapability(InternetExplorerDriver.ELEMENT_SCROLL_BEHAVIOR,ElementScrollBehavior.BOTTOM);
		cap.setCapability(InternetExplorerDriver.IE_ENSURE_CLEAN_SESSION, true);
		cap.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS,true);
		cap.setCapability(InternetExplorerDriver.UNEXPECTED_ALERT_BEHAVIOR,UnexpectedAlertBehaviour.IGNORE);
		cap.setCapability(InternetExplorerDriver.REQUIRE_WINDOW_FOCUS,true);
		cap.setCapability("ignoreProtectedModeSettings", true);
		cap.setJavascriptEnabled(true); 
		cap.setCapability(InternetExplorerDriver.IGNORE_ZOOM_SETTING, true);
		
		return cap;
	}
	
	public WebDriver getIExplorerDriver(Capabilities cap)
	{
		System.setProperty("webdriver.ie.driver", System.getProperty("user.dir")+"/drivers/IE/2.53.1/IEDriverServer.exe");
		return new InternetExplorerDriver(cap);
	}
	public WebDriver getIExplorerDriver()
	{
		 DesiredCapabilities ieCapabilities = DesiredCapabilities.internetExplorer();      
	      
	    ieCapabilities.setCapability("ignoreProtectedModeSettings", true);    
		System.setProperty("webdriver.ie.driver", System.getProperty("user.dir")+"/drivers/IE/2.53.1/IEDriverServer.exe");
		return new InternetExplorerDriver(ieCapabilities);
	}
	public Capabilities getFirefoxCapabilities() {
		DesiredCapabilities firefox = DesiredCapabilities.firefox();
		FirefoxProfile profile = new FirefoxProfile();
		profile.setAcceptUntrustedCertificates(true);
		profile.setAssumeUntrustedCertificateIssuer(true);
		firefox.setCapability(FirefoxDriver.PROFILE, profile);
		firefox.setCapability("marionette", true);
		return firefox;
	}
	
	public WebDriver getFirefoxDriver(Capabilities cap) {
		System.setProperty("webdriver.gecko.driver", System.getProperty("user.dir")+"/drivers/firefox/geckodriver.exe");
		return new FirefoxDriver(cap);
	}
	
	
	public String takeScreenShot(String name) throws IOException {

		if (driver instanceof HtmlUnitDriver) 
		{
			oLog.fatal("HtmlUnitDriver Cannot take the ScreenShot");
			return "";
		}

		File destDir = new File(CONFIG.getProperty("ScreenshotLocation")+getCurrentDate());
		if (!destDir.exists())
			destDir.mkdir();

		File destPath = new File(destDir.getAbsolutePath()+ System.getProperty("file.separator") + name + ".jpg");
		try 
		{
			FileUtils.copyFile(((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE), destPath);
		} catch (IOException e)
		{
			oLog.error(e);
			throw e;
		}
		oLog.info(destPath.getAbsolutePath());
		return destPath.getAbsolutePath();
	}

	public String takeScreenShot() 
	{
		oLog.info("Going to Take the ScreenShot");
		return ((TakesScreenshot) driver).getScreenshotAs(OutputType.BASE64);
	}
	
	
	
	 @When("^that Launch Application '(.+)' URL$")
	    public void sampleUserDefinedOpenLink(String url) {
		 	oLog.info("The Configuration WebSite URL is \t:\t"+CONFIG.getProperty(url));
		 	System.out.println("The Configuration WebSite URL is \t:\t"+CONFIG.getProperty(url));
	        driver.get(CONFIG.getProperty(url));
	        
	    }
		
	 public void startRecording() throws Exception
	 {    
		 File file = new File(CONFIG.getProperty("VideosLocation"));

		 Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		 int width = screenSize.width;
		 int height = screenSize.height;

		 Rectangle captureSize = new Rectangle(0,0, width, height);

		 GraphicsConfiguration gc = GraphicsEnvironment
				 .getLocalGraphicsEnvironment()
				 .getDefaultScreenDevice()
				 .getDefaultConfiguration();

		 this.screenRecorder = new SpecializedScreenRecorder(gc, captureSize,
				 new Format(MediaTypeKey, MediaType.FILE, MimeTypeKey, MIME_AVI),
				 new Format(MediaTypeKey, MediaType.VIDEO, EncodingKey, ENCODING_AVI_TECHSMITH_SCREEN_CAPTURE,
						 CompressorNameKey, ENCODING_AVI_TECHSMITH_SCREEN_CAPTURE,
						 DepthKey, 24, FrameRateKey, Rational.valueOf(15),
						 QualityKey, 1.0f,
						 KeyFrameIntervalKey, 15 * 60),
						 new Format(MediaTypeKey, MediaType.VIDEO, EncodingKey, "black",
								 FrameRateKey, Rational.valueOf(30)),
								 null, file, "MyVideo");
		 this.screenRecorder.start();

	 }

     public void stopRecording() throws Exception
     {
       this.screenRecorder.stop();
       oLog.info("Stopped the Video");
     }
	

 	
 	@Then("^Store Data from the \"(.*?)\" and the \"(.*?)\" for the Rows \"(.*?)\" dataset$")
     public void i_contact_the_customer_service_with_excel_row_dataset(String FileName,String SheetName,String rowindex) throws Throwable {
 		 index=0;
         index = Integer.parseInt(rowindex)-1;
         System.out.println("Printing current data set..."+index);
         datamap = DataHelper.data(System.getProperty("user.dir")+"/src/test/resources/testData/"+FileName+".xlsx",SheetName);
         for(HashMap h:datamap)
         {
             System.out.println(h.keySet());
             System.out.println(h.values());
         }
         tempindex=index;
      

     }
 	
	
}

