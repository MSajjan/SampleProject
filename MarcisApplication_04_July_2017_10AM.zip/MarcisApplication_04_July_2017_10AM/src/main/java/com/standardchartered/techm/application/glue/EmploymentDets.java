package com.standardchartered.techm.application.glue;

import com.standardchartered.techm.application.utils.Wrapper;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class EmploymentDets {
	public Wrapper mywrapper= new Wrapper();
	
	@Then("^Enter details in Employment Details page$")
	public void Enter_details_in_Employment_Details_page() throws InterruptedException
	{
		mywrapper.hardWait(15000);
		mywrapper.SwitchToWindowViaWindowTitle(BaseClass.driver, "Employment Details");
		mywrapper.hardWait(5000);
		//mywrapper.SelectUsingValue(BaseClass.driver,BaseClass.OBJECT.getProperty("Employer_Type_Employment_Details"),BaseClass.datamap.get(BaseClass.tempindex).get("Employment_Type"));
		mywrapper.clearAndSendKeys(BaseClass.driver,BaseClass.OBJECT.getProperty("Employer_Code_Employment_Details"),BaseClass.datamap.get(BaseClass.tempindex).get("Employer_Code"));
		mywrapper.SelectUsingValue(BaseClass.driver,BaseClass.OBJECT.getProperty("Position_Held_Employment_Details"),BaseClass.datamap.get(BaseClass.tempindex).get("Position_Held"));
		mywrapper.clearAndSendKeys(BaseClass.driver,BaseClass.OBJECT.getProperty("Employee_No_Employment_Details"),BaseClass.datamap.get(BaseClass.tempindex).get("Employee_No"));
		//mywrapper.SelectUsingValue(BaseClass.driver, "//select[@name='mszcmbEmpCode']", "2166");
		mywrapper.SelectUsingValue(BaseClass.driver,BaseClass.OBJECT.getProperty("Employment_No_Employment_Details"),BaseClass.datamap.get(BaseClass.tempindex).get("Emplyee_code"));
		mywrapper.SelectUsingValue(BaseClass.driver,BaseClass.OBJECT.getProperty("Salary_Day_Employment_Details"),BaseClass.datamap.get(BaseClass.tempindex).get("Salary_Day"));
		mywrapper.clearAndSendKeys(BaseClass.driver,BaseClass.OBJECT.getProperty("Empl_Yrs_Employment_Details"),BaseClass.datamap.get(BaseClass.tempindex).get("Empl_yrs"));
		mywrapper.clearAndSendKeys(BaseClass.driver,BaseClass.OBJECT.getProperty("Empl_Mths_Employment_Details"),BaseClass.datamap.get(BaseClass.tempindex).get("Empl_Mth"));
		//Enter code for Date of Commencement
		//mywrapper.clearAndSendKeys(BaseClass.driver,BaseClass.OBJECT.getProperty("Dt_Of_Commencement_Employment_Details"),"01/10/1992");
		//mywrapper.clearAndSendKeys(BaseClass.driver,BaseClass.OBJECT.getProperty("Address1_Employment_Details"),BaseClass.datamap.get(BaseClass.tempindex).get("Address1"));
		mywrapper.SelectUsingValue(BaseClass.driver,BaseClass.OBJECT.getProperty("Country_of_Employment_Employment_Details"),BaseClass.datamap.get(BaseClass.tempindex).get("Country_of_Employment"));
		//mywrapper.clearAndSendKeys(BaseClass.driver,BaseClass.OBJECT.getProperty("City_Employment_Details"),BaseClass.datamap.get(BaseClass.tempindex).get("City_of_Employment"));
		mywrapper.clearAndSendKeys(BaseClass.driver,BaseClass.OBJECT.getProperty("Phone_No_1_Employment_Details"),BaseClass.datamap.get(BaseClass.tempindex).get("Phone_No"));
		mywrapper.click(BaseClass.driver, BaseClass.OBJECT.getProperty("Save_Employment_Details"));
		mywrapper.hardWait(10000);
		mywrapper.close(BaseClass.driver);
		
	}
	

}
