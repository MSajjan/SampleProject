package com.standardchartered.techm.application.glue;

import com.standardchartered.techm.application.utils.Wrapper;

import cucumber.api.java.en.Then;

public class DataEntryMain {

	public Wrapper mywrapper= new Wrapper();
	
	@Then("^Click on Reference in Data-Entry Main page$")
	public void click_on_reference_in_data_entry_main_page() throws Exception
	{
		mywrapper.hardWait(2000);
		if(CommonBusinessLogic.mainwindow!=null)
		{
			mywrapper.SwitchToWindow(BaseClass.driver, CommonBusinessLogic.mainwindow);
		}
		else
		{
			mywrapper.SwitchToDefaultWindow(BaseClass.driver);
		}
		mywrapper.hardWait(2000);
		mywrapper.SwitchToDefaultWindow(BaseClass.driver);
		mywrapper.switchToFrame(BaseClass.driver, "content");
		mywrapper.hardWait(2000);
		mywrapper.click(BaseClass.driver, BaseClass.OBJECT.getProperty("Data_Entry_References"));
	
	}
	
	@Then("^Click on Loan Details Button in Data-Entry Main page$")
	public void click_on_loan_details_button() throws Exception
	{
		if(CommonBusinessLogic.mainwindow!=null)
		{
			mywrapper.SwitchToWindow(BaseClass.driver, CommonBusinessLogic.mainwindow);
		}
		else
		{
			mywrapper.SwitchToDefaultWindow(BaseClass.driver);
		}
		mywrapper.hardWait(5000);
		mywrapper.SwitchToDefaultWindow(BaseClass.driver);
		mywrapper.switchToFrame(BaseClass.driver, "content");
		mywrapper.hardWait(2000);
		CommonBusinessLogic.ParentWindow=mywrapper.getWindowHandle(BaseClass.driver);
	mywrapper.click(BaseClass.driver, BaseClass.OBJECT.getProperty("Data_Entry_Loan_Details"));
	
	}
	
	@Then("^Click on Decision Button in Data-Entry Main page$")
	public void click_on_decision_in_data_entry_main_page() throws Exception
	{
		if(CommonBusinessLogic.mainwindow!=null)
		{
			mywrapper.SwitchToWindow(BaseClass.driver, CommonBusinessLogic.mainwindow);
		}
		else
		{
			mywrapper.SwitchToDefaultWindow(BaseClass.driver);
		}
		mywrapper.hardWait(5000);
		mywrapper.SwitchToDefaultWindow(BaseClass.driver);
		mywrapper.switchToFrame(BaseClass.driver, "content");
		mywrapper.hardWait(2000);
		mywrapper.click(BaseClass.driver, BaseClass.OBJECT.getProperty("Data_Entry_Decision"));
	
	}
	
}
