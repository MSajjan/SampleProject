package com.standardchartered.techm.application.glue;

import java.util.List;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.standardchartered.techm.application.utils.Wrapper;

import cucumber.api.java.en.Then;

public class BankDetailsScreen {
	public Wrapper mywrapper= new Wrapper();
	
	@Then("^Navigate to Bank Details window and click on Add row$")
	public void addrowDetails() throws InterruptedException
	{
		mywrapper.hardWait(5000);
		mywrapper.SwitchToWindowViaWindowTitle(BaseClass.driver, "Applicant Bank Details");
		mywrapper.hardWait(5000);
		mywrapper.javascriptEx_Click(BaseClass.driver, BaseClass.OBJECT.getProperty("addrow_bankdetails"));
		mywrapper.hardWait(9000);
		CommonBusinessLogic.ParentWindow=mywrapper.getWindowHandle(BaseClass.driver);
	}
	
	@Then("^Enter Acc No and Months open in Bank Details screen$")
	public void enter_Acc_No_and_Months_open_in_bank_details_screen() throws InterruptedException
	{	
		mywrapper.SwitchToWindowViaWindowTitle(BaseClass.driver, "Applicant Bank Details");
		mywrapper.hardWait(5000);
		if(BaseClass.driver.findElement(By.xpath("//table[@id='tblDetails']")).isDisplayed())
		{
			System.out.println("Table is displayed");
			List<WebElement> tablerows=BaseClass.driver.findElements(By.xpath("//table[@id='tblDetails']//td//input[@type='text']"));
			tablerows.get(2).sendKeys(BaseClass.datamap.get(BaseClass.tempindex).get("Acc_No"));
			tablerows.get(5).sendKeys(BaseClass.datamap.get(BaseClass.tempindex).get("Months_Open"));
		}
		else
		{
			Assert.fail("Table is Not present");
		}
		mywrapper.hardWait(3000);
		
	}
	
	
	@Then("^Click save Button in Bank Details and Close the Bank Details Screen$")
	public void click_save_button_in_bank_details_and_close_the_bank_details_screen() throws InterruptedException
	{	
		mywrapper.hardWait(3000);
		mywrapper.click(BaseClass.driver, BaseClass.OBJECT.getProperty("Save_BankDetails"));
		mywrapper.hardWait(3000);
		/*mywrapper.hardWait(3000);
		mywrapper.close(BaseClass.driver);*/
	}
	
}
