package com.standardchartered.techm.application.glue;

import java.util.List;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.standardchartered.techm.application.utils.Wrapper;

import cucumber.api.java.en.Then;

public class DecisionScreen {

	public Wrapper mywrapper= new Wrapper();
	
	@Then("^Click on view decision button$")
	public void click_on_view_decision() throws InterruptedException
	{
		mywrapper.SwitchToWindow(BaseClass.driver, CommonBusinessLogic.ParentWindow);
		mywrapper.hardWait(5000);
		mywrapper.SwitchToDefaultWindow(BaseClass.driver);
		mywrapper.switchToFrame(BaseClass.driver, "content");
		mywrapper.hardWait(4000);
		mywrapper.click(BaseClass.driver, BaseClass.OBJECT.getProperty("Decision_Screen_View_Decision"));
		mywrapper.hardWait(4000); 		
	}
	
	@Then("^Click on action in decision screen$")
	public void click_on_action_in_decision() throws InterruptedException
	{
		
		
		mywrapper.SwitchToDefaultWindow(BaseClass.driver);
		mywrapper.switchToFrame(BaseClass.driver, "content");
		mywrapper.click(BaseClass.driver, BaseClass.OBJECT.getProperty("Decision_Screen_Forward"));
		mywrapper.hardWait(4000); 	
		mywrapper.javaScriptExec_SendKeys(BaseClass.driver,BaseClass.OBJECT.getProperty("Decision_Screen_notes") ,"OK- approved by DD Maker using automation");
		mywrapper.hardWait(2000); 	
		mywrapper.javascriptEx_Click(BaseClass.driver, BaseClass.OBJECT.getProperty("Decision_Screen_Action"));
		mywrapper.hardWait(8000); 
		mywrapper.SwitchToDefaultWindow(BaseClass.driver);
		mywrapper.switchToFrame(BaseClass.driver, "content");
		String Success_Text=mywrapper.getElement(BaseClass.driver, BaseClass.OBJECT.getProperty("Decision_Success")).getText();
		Assert.assertTrue("Operation Successful message is Not Displayed",Success_Text.equals("Operation Successful"));
		
		
		
	}
	
	@SuppressWarnings("deprecation")
	@Then("^Click Approve and Click Action$")
	public void clickApproveClickAction() throws Exception
	{
		mywrapper.click(BaseClass.driver, "//input[@id='radApprove']");
		mywrapper.click(BaseClass.driver, "//input[@name='cmdAction' and @value='Action']");
		
		mywrapper.AcceptAlertIfPresent(BaseClass.driver);
		mywrapper.hardWait(5000);
		List<WebElement> element=BaseClass.driver.findElements(By.xpath(BaseClass.OBJECT.getProperty("OperationSucessful")));
		Assert.assertTrue("Operation Successful Message doesnot appear, Please verify the Screenshot for the Reference",element.size()==1);	
	}
	
	@Then("^Fill decision screen and Click Action$")
	public void Fill_decision_screen_and_Click_Action() throws Exception
	{
		mywrapper.clearAndSendKeys(BaseClass.driver, BaseClass.OBJECT.getProperty("Decision_Screen_Notes"),BaseClass.datamap.get(BaseClass.tempindex).get("Decision_Screen_Notes"));
		mywrapper.click(BaseClass.driver, BaseClass.OBJECT.getProperty("Decision_Screen_Forward"));
		mywrapper.click(BaseClass.driver, BaseClass.OBJECT.getProperty("Decision_Screen_Action"));
	}
	

}
