package com.standardchartered.techm.application.glue;

import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;

import com.standardchartered.techm.application.utils.Wrapper;

import cucumber.api.java.en.Then;

public class DocumentDetailsScreen {
	
public Wrapper mywrapper= new Wrapper();
	
	@Then("^select all received,checked checkbox along with dates and comments and click savebutton$")
	public void clickonDocEntryButtoninDisburement() throws InterruptedException
	{
		mywrapper.hardWait(5000);
		mywrapper.SwitchToWindowViaWindowTitle(BaseClass.driver, "Document Details");
		mywrapper.hardWait(4000);

		Set<String> mywindows=mywrapper.getWindowHandlens(BaseClass.driver);
		System.out.println(mywindows.size());
		Set<String> mywind=BaseClass.driver.getWindowHandles();
		System.out.println(mywind.size());
		Set<String> testqw=mywrapper.getWindowHandlens(BaseClass.driver);
		System.out.println(testqw.size());
		String value="03/07/2017";
		List<WebElement> received_checkbox=BaseClass.driver.findElements(By.xpath("//input[@name='mszchkReceived']"));
		for(int i=0;i<received_checkbox.size();i++)
		{
			if(!received_checkbox.get(i).isSelected()){
				received_checkbox.get(i).click();
			}
		}
		List<WebElement> checked_checkbox=BaseClass.driver.findElements(By.xpath("//table[@id='tblDocumentDetails']//input[@name='nctChecked']"));
		for(int i=0;i<checked_checkbox.size();i++)
		{
			if(!checked_checkbox.get(i).isSelected()){
				checked_checkbox.get(i).click();
			}
		}
		List<WebElement> date_received=BaseClass.driver.findElements(By.xpath("//table[@id='tblDocumentDetails']//input[@name='msztxtReceivedDate']"));
		for(int i=0;i<date_received.size();i++)
		{
			if(date_received.get(i).getAttribute("value").isEmpty())
			{
				WebElement test=date_received.get(i);
				((JavascriptExecutor)BaseClass.driver).executeScript("arguments[0].value = '"+value+"'", test);

			}
		}
		List<WebElement> comments=BaseClass.driver.findElements(By.xpath("//table[@id='tblDocumentDetails']//textarea"));
		for(int i=0;i<comments.size();i++)
		{
			comments.get(i).sendKeys("tested OK");
		}

		mywrapper.click(BaseClass.driver, "//input[@name='cmdSave']");
		mywrapper.hardWait(5000);
	}

}

