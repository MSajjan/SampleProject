package com.standardchartered.techm.application.glue;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;

import com.standardchartered.techm.application.utils.Wrapper;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class IncomeDetailsScreen {

	public Wrapper mywrapper= new Wrapper();

	
	
	
	@Given("^Enter the IncomeTax Details Screen$")
	public void enterIncomeTaxDetailsScreen() throws InterruptedException
	{
		mywrapper.hardWait(15000);
		mywrapper.SwitchToWindowViaWindowTitle(BaseClass.driver, "Applicant Income Details");
		mywrapper.hardWait(5000);
		mywrapper.onlySendKeys(BaseClass.driver, BaseClass.OBJECT.getProperty("salaryincome_incomeTax"), BaseClass.datamap.get(BaseClass.tempindex).get("IncomeTax_Salary_Income"));
		mywrapper.onlySendKeys(BaseClass.driver, BaseClass.OBJECT.getProperty("commearn_incomeTax"), BaseClass.datamap.get(BaseClass.tempindex).get("IncomeTax_CommEarn"));
		mywrapper.onlySendKeys(BaseClass.driver, BaseClass.OBJECT.getProperty("investments_incomeTax"), BaseClass.datamap.get(BaseClass.tempindex).get("IncomeTax_Investments"));
		mywrapper.onlySendKeys(BaseClass.driver, BaseClass.OBJECT.getProperty("property_incomeTax"), BaseClass.datamap.get(BaseClass.tempindex).get("IncomeTax_PropertyRental"));
		mywrapper.onlySendKeys(BaseClass.driver, BaseClass.OBJECT.getProperty("other_incomeTax"), BaseClass.datamap.get(BaseClass.tempindex).get("IncomeTax_Other"));
		mywrapper.onlySendKeys(BaseClass.driver, BaseClass.OBJECT.getProperty("bonus_incomeTax"), BaseClass.datamap.get(BaseClass.tempindex).get("IncomeTax_Bonus"));
	}
	
	@Then("^Click on the Save Button in the IncomeTax Details Screen$")
	public void clickSaveinIncomeTaxDetailsScreen() throws InterruptedException
	{
		mywrapper.javascriptEx_Click(BaseClass.driver,BaseClass.OBJECT.getProperty("save_incomeTax"));
		mywrapper.hardWait(9000);
	}
	
}
