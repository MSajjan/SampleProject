package com.standardchartered.techm.application.glue;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Set;

import org.joda.time.DateTime;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.standardchartered.techm.application.utils.Wrapper;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class CommonBusinessLogic {
	public Wrapper mywrapper= new Wrapper();
	public static String ParentWindow=null;
	public static String childWindow=null;
	public static String LoanNo;
	public static String CusNo;
	public static String customersignedDate=null;
	public static String businessDate=null;
	public static String dateLoan=null;	
	public static String mainwindow=null;

	
	{
		ParentWindow=mywrapper.getWindowHandle(BaseClass.driver);
	}
	
	@Then("^Close childWindow$")
	public void Close_childWindow() throws Exception
	{
		mywrapper.hardWait(1000);
		mywrapper.close(BaseClass.driver);
		mywrapper.hardWait(2000);
	}
	
	@Then("^Switch to MainWindow$")
	public void switchtoMainWindow()
	{
		mywrapper.SwitchToWindow(BaseClass.driver, CommonBusinessLogic.mainwindow);
	}
	@Then("^Navigate from \"(.*)\" menu to \"(.*)\" submenu$")
	public void NavigatetosubmenuScreen(String menuItem,String submenuItem) throws InterruptedException
	{
		/*String menuitemValue=BaseClass.OBJECT.getProperty("menuItem").replace("**data**", menuItem);
		String submenuitemValue=BaseClass.OBJECT.getProperty("submenuItem").replace("**data**", submenuItem);
		*/
		String menuitemValue=mywrapper.replaceData(BaseClass.driver, BaseClass.OBJECT.getProperty("menuItem"), menuItem);
		String submenuitemValue=mywrapper.replaceData(BaseClass.driver,BaseClass.OBJECT.getProperty("submenuItem"), submenuItem);
		mywrapper.hardWait(2000);
		mywrapper.SwitchToDefaultWindow(BaseClass.driver);
		mywrapper.switchToFrame(BaseClass.driver, "menu");		
		mywrapper.click(BaseClass.driver, menuitemValue);
		mywrapper.hardWait(1000);
		mywrapper.SwitchToDefaultWindow(BaseClass.driver);
		mywrapper.switchToFrame(BaseClass.driver, "content");		
		mywrapper.click(BaseClass.driver, submenuitemValue);
		mywrapper.hardWait(3000);
	}
	

	@Then("^Click on the \"([^\"]*)\" and Switch to \"([^\"]*)\" and Select the \"([^\"]*)\" inside dialog in childwindow$")
	public void SelectValueinModalDialog(String objectproperty,String modalname,String selectItem) throws InterruptedException
	{
		boolean flag=false;
		
		String childWindows=mywrapper.getWindowHandle(BaseClass.driver);
		mywrapper.SwitchToWindow(BaseClass.driver, childWindows);
		//CommonBusinessLogic.ParentWindow=mywrapper.getWindowHandle(BaseClass.driver);
		
		mywrapper.click(BaseClass.driver, BaseClass.OBJECT.getProperty(objectproperty));
		mywrapper.hardWait(5000);
		Set<String> handles = BaseClass.driver.getWindowHandles();
		int sizea=handles.size();
		mywrapper.hardWait(5000);
		handles = BaseClass.driver.getWindowHandles();
		int sizeb=handles.size();
		System.out.println("Initial after 5 secnds"+sizea+"\t after the 10 seconds\t:\t"+sizeb);
		for(String handle : handles)
		{
		        // Here will block for ever. No exception and timeout!
		        WebDriver popup = BaseClass.driver.switchTo().window(handle);
		        System.out.println(BaseClass.driver.getTitle());
		        if(BaseClass.driver.getTitle().equalsIgnoreCase(modalname))
		        {
		        	String goingtoSelectItem=mywrapper.replaceData(BaseClass.driver, BaseClass.OBJECT.getProperty("select_item_from_dialog"), selectItem);
		        	mywrapper.click(BaseClass.driver,goingtoSelectItem);
		        	mywrapper.Sendkeys_Tab(BaseClass.driver,goingtoSelectItem, Keys.TAB);
		        	mywrapper.Sendkeys_Tab(BaseClass.driver,goingtoSelectItem, Keys.ENTER);
		        	flag=true;
		        }
		        if(flag)
		        	break;
		}
		mywrapper.hardWait(5000);
		BaseClass.driver.switchTo().window(childWindows);
		
	}
	
	
	@Then("^Click on the \"([^\"]*)\" and Switch to \"([^\"]*)\" and Select the \"([^\"]*)\" inside dialog in parentwindow$")
	public void SelectValueinModalDialoginparentwindow(String objectproperty,String modalname,String selectItem) throws InterruptedException
	{
		JavascriptExecutor jse = (JavascriptExecutor)BaseClass.driver;
		jse.executeScript("window.scrollBy(0,120)", "");
		boolean flag=false;
		mywrapper.SwitchToDefaultWindow(BaseClass.driver);
		mywrapper.switchToFrame(BaseClass.driver,"content");
		mywrapper.hardWait(3000);
		String parentWindow= BaseClass.driver.getWindowHandle();
		mywrapper.click(BaseClass.driver, BaseClass.OBJECT.getProperty(objectproperty));
		mywrapper.hardWait(5000);
		Set<String> handles = BaseClass.driver.getWindowHandles();
		int sizea=handles.size();
		mywrapper.hardWait(5000);
		handles = BaseClass.driver.getWindowHandles();
		int sizeb=handles.size();
		System.out.println("Initial after 10 secnds"+sizea+"\t after the 10 seconds\t:\t"+sizeb);
		for(String handle : handles)
		{
		        // Here will block for ever. No exception and timeout!
		        WebDriver popup = BaseClass.driver.switchTo().window(handle);
		        System.out.println(BaseClass.driver.getTitle());
		        if(BaseClass.driver.getTitle().equalsIgnoreCase(modalname))
		        {
		        	String goingtoSelectItem=mywrapper.replaceData(BaseClass.driver, BaseClass.OBJECT.getProperty("select_item_from_dialog"), selectItem);
		        	mywrapper.click(BaseClass.driver,goingtoSelectItem);
		        	mywrapper.Sendkeys_Tab(BaseClass.driver,goingtoSelectItem, Keys.TAB);
		        	mywrapper.Sendkeys_Tab(BaseClass.driver,goingtoSelectItem, Keys.ENTER);
		        	flag=true;
		        }
		        if(flag)
		        	break;
		}
		mywrapper.hardWait(5000);
		BaseClass.driver.switchTo().window(parentWindow);
		
	}
	@Then("^Click on the \"([^\"]*)\" Number$")
	public void clickNumberthroughLink(String number) throws InterruptedException
	{
		mywrapper.SwitchToDefaultWindow(BaseClass.driver);
		mywrapper.switchToFrame(BaseClass.driver,"content");
		mywrapper.hardWait(3000);
		String numberlink=mywrapper.replaceData(BaseClass.driver, BaseClass.OBJECT.getProperty("loanapplicatonNo"), number);
		mywrapper.click(BaseClass.driver, numberlink);
		mywrapper.hardWait(3000);
		
	}
	@Then("^Get the CustomerSigned Date and DateReceived Date$")
	public void getCustomerSignedDate() throws InterruptedException, ParseException
	{
		mywrapper.SwitchToDefaultWindow(BaseClass.driver);
		mywrapper.switchToFrame(BaseClass.driver,"menu");
		mywrapper.hardWait(2000);
		System.out.println("business Date \t:\t["+BaseClass.driver.findElement(By.xpath("//td[contains(text(),'Business Date:')]")).getText().replaceAll("Business Date:", "").trim()+"]");
		
		System.out.println("business Date \t:\t["+BaseClass.driver.findElement(By.xpath("//td[contains(text(),'Last Logged On:')]")).getText().replaceAll("Last Logged On:", "").trim()+"]");
		
		
		String SystemDate=BaseClass.driver.findElement(By.xpath("//td[contains(text(),'Business Date:')]")).getText().replaceAll("Business Date:", "").trim();
		
		Date date1=new SimpleDateFormat("dd/MM/yyyy").parse(SystemDate);  
	    System.out.println(SystemDate+"\t"+date1);
	    CommonBusinessLogic.businessDate=date1.toString();
	    CommonBusinessLogic.dateLoan=date1.toString();
	    Date customersignedDate= new DateTime(date1).minusDays(1).toDate();
	    System.out.println(customersignedDate);
	    CommonBusinessLogic.customersignedDate=customersignedDate.toString();
	    DateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
	    
	    String customersinedDateString=formatter.format(customersignedDate);
	    System.out.println(customersinedDateString);

	}
	@Given("^Click on the \"([^\"]*)\" in the DD Checker$")
	public void clickLoanApplicationNumber(String num) throws InterruptedException
	{
		String applicationLoanNumber=CommonBusinessLogic.LoanNo;
		String customerNumber=CommonBusinessLogic.CusNo;
		String relatedxpath = "";
		if(!(applicationLoanNumber==null && customerNumber==null ))
		{
			if(num.equalsIgnoreCase("applicationnumber"))
			{
				String myxpath=BaseClass.OBJECT.getProperty("loanapplicatonNo");
				relatedxpath=mywrapper.replaceData(BaseClass.driver, myxpath, applicationLoanNumber);
			}
			else if(num.equalsIgnoreCase("customerno"))
			{
				String myxpath=BaseClass.OBJECT.getProperty("loanapplicatonNo");
				relatedxpath=	mywrapper.replaceData(BaseClass.driver, myxpath, customerNumber);
			}
		}
		mywrapper.SwitchToDefaultWindow(BaseClass.driver);
		mywrapper.switchToFrame(BaseClass.driver,"content");
		mywrapper.hardWait(5000);
		mywrapper.click(BaseClass.driver, relatedxpath);
		mywrapper.hardWait(5000);
		
	}@Given("^Click on the \"(.*)\" to Navigate \"(.*)\" screen$")
	public void navigateScreenthroughButton(String buttonName,String ScreenName) throws InterruptedException
	{
		mywrapper.SwitchToDefaultWindow(BaseClass.driver);
		
		mywrapper.switchToFrame(BaseClass.driver,"content");
		mywrapper.hardWait(3000);
		String actualbuttonname=mywrapper.replaceData(BaseClass.driver, BaseClass.OBJECT.getProperty("commonbutton"), buttonName);
		mywrapper.javascriptEx_Click(BaseClass.driver, actualbuttonname);
		mywrapper.hardWait(10000);
		mywrapper.SwitchToDefaultWindow(BaseClass.driver);
		mywrapper.switchToFrame(BaseClass.driver,"content");
		mywrapper.hardWait(5000);
		
	}
	
//	@And("^enter valid credentials$")
//	public void enter_valid_credentails() throws Throwable 
//	{
//		System.out.println("Enter the Valid Credentials");
//		mywrapper.clearAndSendKeys(BaseClass.driver,BaseClass.OBJECT.getProperty("User_ID_LoginPage"),BaseClass.datamap.get(BaseClass.tempindex).get("username"));
//		mywrapper.clearAndSendKeys(BaseClass.driver,BaseClass.OBJECT.getProperty("Pwd_LoginPage"),BaseClass.datamap.get(BaseClass.tempindex).get("password"));
//		mywrapper.clearAndSendKeys(BaseClass.driver,BaseClass.OBJECT.getProperty("Portfolio_LoginPage"),BaseClass.datamap.get(BaseClass.tempindex).get("Portfolio"));
//		mywrapper.clearAndSendKeys(BaseClass.driver,BaseClass.OBJECT.getProperty("Branch_LoginPage"),BaseClass.datamap.get(BaseClass.tempindex).get("Branch"));
//		mywrapper.SelectUsingValue(BaseClass.driver,BaseClass.OBJECT.getProperty("Country_LoginPage"),BaseClass.datamap.get(BaseClass.tempindex).get("Country"));
//	}
//	
//	@Then("^click on Login button$")
//	public void click_on_Login_button() throws InterruptedException
//	{
//		System.out.println("Click on Login button");
//		mywrapper.click(BaseClass.driver, BaseClass.OBJECT.getProperty("Login_Button_LoginPage"));
//		mywrapper.hardWait(2000);
//		
//	}
//	
//	@And("^handle expiry warning popup$")
//	public void handle_expiry_warning_popup() throws Exception
//	{
//		System.out.println("handle expiry warning popup");
//		mywrapper.AcceptAlertIfPresent(BaseClass.driver);
//		mywrapper.hardWait(2000);
//	}
}
