package com.standardchartered.techm.application.glue;

import com.standardchartered.techm.application.utils.Wrapper;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;

public class DataMatchReviewScreen {
	public Wrapper mywrapper= new Wrapper();
	@Then("^Enter Match Details Screen and Click on Match Details Button$")
	public void click_on_View_Match_Details() throws Exception
	{
		mywrapper.hardWait(2000);
		System.out.println("click on View Match Details");
		mywrapper.SwitchToDefaultWindow(BaseClass.driver);
		mywrapper.switchToFrame(BaseClass.driver, BaseClass.OBJECT.getProperty("Content_Frame"));
		mywrapper.hardWait(5000);
		mywrapper.SelectUsingValue(BaseClass.driver,BaseClass.OBJECT.getProperty("Title_Matching"),BaseClass.datamap.get(BaseClass.tempindex).get("Title"));
		mywrapper.javaScriptExec_clearAndSendKeys(BaseClass.driver,BaseClass.OBJECT.getProperty("FirstName_Matching"),BaseClass.datamap.get(BaseClass.tempindex).get("First_name"));
		mywrapper.javaScriptExec_clearAndSendKeys(BaseClass.driver,BaseClass.OBJECT.getProperty("LastName_DaMatching"),BaseClass.datamap.get(BaseClass.tempindex).get("Last_name"));
		mywrapper.javaScriptExec_clearAndSendKeys(BaseClass.driver,BaseClass.OBJECT.getProperty("Telephone_No_Matching"),BaseClass.datamap.get(BaseClass.tempindex).get("Telephone_No"));

		
		
		
		CommonBusinessLogic.ParentWindow=mywrapper.getWindowHandle(BaseClass.driver);
		mywrapper.hardWait(2000);
		mywrapper.click(BaseClass.driver, BaseClass.OBJECT.getProperty("Calender"));
		mywrapper.hardWait(20000);
		mywrapper.SwitchToWindowViaWindowTitle(BaseClass.driver, "Calender");
		mywrapper.hardWait(5000);
		mywrapper.javascriptEx_Click(BaseClass.driver,BaseClass.OBJECT.getProperty("Calender_Months"));
		mywrapper.hardWait(5000);
		mywrapper.SelectUsingValue(BaseClass.driver,BaseClass.OBJECT.getProperty("Calender_Months"), "3");
		mywrapper.hardWait(5000);
		mywrapper.javascriptEx_Click(BaseClass.driver,BaseClass.OBJECT.getProperty("Calender_Years"));
		mywrapper.hardWait(10000);
		mywrapper.SelectUsingValue(BaseClass.driver,BaseClass.OBJECT.getProperty("Calender_Years"), "1990");
		mywrapper.hardWait(10000);
		mywrapper.javascriptEx_Click(BaseClass.driver,BaseClass.OBJECT.getProperty("Calender_Date"));
		mywrapper.hardWait(10000);
		//mywrapper.SwitchToDefaultWindow(BaseClass.driver);
		
		mywrapper.SwitchToWindow(BaseClass.driver, CommonBusinessLogic.ParentWindow);
		mywrapper.SwitchToDefaultWindow(BaseClass.driver);
		mywrapper.switchToFrame(BaseClass.driver, BaseClass.OBJECT.getProperty("Content_Frame"));
		mywrapper.hardWait(3000);
		mywrapper.click(BaseClass.driver, BaseClass.OBJECT.getProperty("Match_Details_Matching"));
		//code for calendar needs to implemented
	}


	@Then("^Click on View Match DetailsButton$")
	public void clickonViewMatchDetailsButton() throws Exception
	{
		mywrapper.hardWait(3000);
		System.out.println("Matching review Screen-2 (clickonViewMatchDetailsButton)");
		mywrapper.SwitchToDefaultWindow(BaseClass.driver);
		mywrapper.switchToFrame(BaseClass.driver, BaseClass.OBJECT.getProperty("Content_Frame"));
		mywrapper.hardWait(5000);
		mywrapper.click(BaseClass.driver, BaseClass.OBJECT.getProperty("View_Match_Details_Matching"));

	}
	
	@Then("^Click on ProceedButton and click ok in Alert popup if present$")
	public void clickonProccedButton() throws Exception
	{
		mywrapper.hardWait(3000);
		System.out.println("Matching Review Screen-3 (clickonProccedButton)");
		mywrapper.SwitchToDefaultWindow(BaseClass.driver);
		mywrapper.switchToFrame(BaseClass.driver, BaseClass.OBJECT.getProperty("Content_Frame"));
		mywrapper.hardWait(5000);
		mywrapper.click(BaseClass.driver, BaseClass.OBJECT.getProperty("proceed_matching"));
		mywrapper.hardWait(2000);
		mywrapper.AcceptAlertIfPresent(BaseClass.driver);
	}

	
}
