package com.standardchartered.techm.application.glue;

import com.standardchartered.techm.application.utils.Wrapper;

import cucumber.api.java.en.Then;

public class LoanDetailsOperationSuccessfulScreen {

	public Wrapper mywrapper= new Wrapper();
	@Then("^Verify Operation Successful message in loan details and click on Go Back$")
	public void Navigate_to_Application_Details_Operation_Screen() throws InterruptedException
	{
		//Object properties pending 
		mywrapper.hardWait(5000);
		/*String Success_Text=mywrapper.getElement(BaseClass.driver, BaseClass.OBJECT.getProperty("operation_success_message_loandetails")).getText();
		if(Success_Text.equals("Operation Successful"))
		{*/
			mywrapper.click(BaseClass.driver, BaseClass.OBJECT.getProperty("goback_loandetails"));
		/*}*/
	}
	
}
