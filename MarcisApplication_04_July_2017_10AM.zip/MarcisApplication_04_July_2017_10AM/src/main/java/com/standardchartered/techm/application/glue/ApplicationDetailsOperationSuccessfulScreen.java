package com.standardchartered.techm.application.glue;

import com.standardchartered.techm.application.utils.Wrapper;

import cucumber.api.java.en.Then;

public class ApplicationDetailsOperationSuccessfulScreen {
	public Wrapper mywrapper= new Wrapper();
	@Then("^Verify Operation Successful message and click on Go Back$")
	public void Navigate_to_Application_Details_Operation_Screen() throws InterruptedException
	{
		mywrapper.SwitchToDefaultWindow(BaseClass.driver);
		mywrapper.switchToFrame(BaseClass.driver, BaseClass.OBJECT.getProperty("Content_Frame"));
		mywrapper.hardWait(10000);
		/*String Success_Text=mywrapper.getElement(BaseClass.driver, BaseClass.OBJECT.getProperty("Application_Details_Operation")).getText();
		if(Success_Text.equals("Operation Successful"))
		{*/
			mywrapper.click(BaseClass.driver, BaseClass.OBJECT.getProperty("Application_Details_Go_Back"));
		/*}*/
	}
	
}
