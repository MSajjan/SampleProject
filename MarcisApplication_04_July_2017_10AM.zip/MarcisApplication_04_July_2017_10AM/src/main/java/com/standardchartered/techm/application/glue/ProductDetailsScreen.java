package com.standardchartered.techm.application.glue;

import com.standardchartered.techm.application.utils.Wrapper;

import cucumber.api.java.en.And;

public class ProductDetailsScreen {

	public Wrapper mywrapper= new Wrapper();
	
	@And("^Enter details in Product Details page$")
	public void Enter_details_in_Product_Details_page() throws Exception
	{
		mywrapper.hardWait(15000);
		mywrapper.SwitchToWindowViaWindowTitle(BaseClass.driver, "Product Details");
		mywrapper.hardWait(5000);
		mywrapper.SelectUsingValue(BaseClass.driver,BaseClass.OBJECT.getProperty("Emp_code_dw"),BaseClass.datamap.get(BaseClass.tempindex).get("Employer_Code"));
		mywrapper.hardWait(10000);
		mywrapper.click(BaseClass.driver,BaseClass.OBJECT.getProperty("Fetch_EmpCode"));
		mywrapper.hardWait(10000);
		mywrapper.SelectUsingValue(BaseClass.driver,BaseClass.OBJECT.getProperty("Product_code_dw"),BaseClass.datamap.get(BaseClass.tempindex).get("Product_Code"));
		mywrapper.hardWait(10000);
		mywrapper.click(BaseClass.driver,BaseClass.OBJECT.getProperty("Fetch_ProductCode"));
		mywrapper.hardWait(10000);
		mywrapper.SelectUsingValue(BaseClass.driver,BaseClass.OBJECT.getProperty("Plan_code_dw"),BaseClass.datamap.get(BaseClass.tempindex).get("Plan_Code"));
		mywrapper.hardWait(5000);
		mywrapper.click(BaseClass.driver,BaseClass.OBJECT.getProperty("GoToMainScreen"));
		mywrapper.hardWait(3000);
		mywrapper.AcceptAlertIfPresent(BaseClass.driver);
		
	}
	
	
}
