package com.standardchartered.techm.application.MarcisApplication;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

import org.junit.runner.RunWith;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;

import com.github.mkolisnyk.cucumber.runner.ExtendedCucumber;
import com.github.mkolisnyk.cucumber.runner.ExtendedCucumberOptions;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
//@RunWith(Cucumber.class)
//@CucumberOptions
//(
//				features={"classpath:features"},
//				glue={"classpath:com.standardchartered.techm.application.glue"},
//				format = { "pretty", "html:target/site/cucumber-pretty", "json:target/cucumber.json"},
//				tags={"@sample1"}
//)


///@RunWith(Cucumber.class)
@RunWith(ExtendedCucumber.class)
@ExtendedCucumberOptions(jsonReport = "target/cucumber.json",
retryCount = 0,
detailedReport = true,
detailedAggregatedReport = true,
overviewReport = true,
coverageReport = true,
jsonUsageReport = "target/cucumber-usage.json",
usageReport = true,
toPDF = true,
/*excludeCoverageTags = {"@flaky" },
includeCoverageTags = {"@passed" },*/
outputFolder = "target")
@CucumberOptions
(
		plugin = { "html:target/cucumber-html-report",
				"json:target/cucumber.json", "pretty:target/cucumber-pretty.txt",
				"usage:target/cucumber-usage.json", "junit:target/cucumber-results.xml" },
				features={"classpath:features"},
				glue={"classpath:com.standardchartered.techm.application.glue"},
				format = { "pretty", "html:target/site/cucumber-pretty", "json:target/cucumber.json"},
		tags={"@DD_Maker_Checker_Kenya"}



)
public class MaricsTest {

}
